/*
 * expression.cpp
 *
 *  Created on: 15:17 PM Friday 2023-2-17
 *      Author: Anonymity
 */

#include <algorithm>
#include <cstdlib>          // size_t

#include "include/abstract/execution.hpp"
#include "include/abstract/expression.hpp"
#include "include/abstract/operand.hpp"
#include "include/optim/operand.hpp"                    // Operand::Compare

namespace abstract {

void Expression::BuildJoin() {
    /* build Expression.io_vertex_index
     * input Operand is built separately
     */
    std::sort(this->input_1d.begin(), this->input_1d.end(), Operand::Compare);
    for (auto &in_op : this->input_1d) {
        // this is a copy
        this->io_vertex_index.push_back(in_op->out_index);
    }
}

std::string Expression::FunctionName() {
    /* create Join part of the function name for expr->output
     * there are two options to build Join function name
     * option 1: group input index by output vertex
     * option 2: group output vertex index by input
     * there is a need to mark non-edge, a special input
     * option 1 does not support marking non-edge
     * because it is not grouped by input
     * option 2 is desired, and is consistent with current function name
     */
    // input output vertex index mapping part
    std::string name;
    if (this->IsJoin()) {
        for (size_t ith = 0; ith < this->io_vertex_index.size(); ith++) {
            name += MarkInput;
            if (this->input_1d[ith]->IsNonedge()) {
                // this join a non-edge, mark it as negation
                name += MarkNegation;
            }
            for (auto index : this->io_vertex_index[ith]) {
                name += (std::to_string(index) + IndexSeparator);
            }
        }
    } else if (this->IsTranspose()) {
        name += MarkInput;
        for (auto &oo : this->io_vertex_index) {
            name += (std::to_string(oo[0]) + IndexSeparator);
        }
    }
    /* create Symmetry Breaking part of the function name
     * each rule is output index, therefore can be sorted
     */
    std::sort(this->symbreak_index.begin(), this->symbreak_index.end(),
            optim::Operand::AscSymBreakRuleValueCount);
    for (auto &rule_index : symbreak_index) {
        name += MarkSymBreak;
        for (auto index : (*rule_index)) {
            name += (std::to_string(index) + IndexSeparator);
        }
    }
    return name;
}

void Expression::PrintDetail(bool end_of_line) {
    Print("Expression=" << this << " output vertex count=");
    Print(this->output->out_index.size() << " io_vertex_index ");
    for (size_t ith = 0; ith < this->io_vertex_index.size(); ith++) {
        Print("[" << ith << "]=");
        PrintArray(this->io_vertex_index[ith],
                this->io_vertex_index[ith].size());
    }
    Print(" symmetry breaking rule (output index)=");
    for (auto *rule : this->symbreak_index) {
        Print("(");
        PrintArray((*rule), rule->size());
        Print(") ");
    }
    Print(" function_name=" << this->FunctionName());
    PrintLine(" input_1d.size()=" << this->input_1d.size());
    for (auto *input : this->input_1d) {
        input->PrintDetail(false);
        Print(" | ");
    }
    if (end_of_line) {
        PrintLine("");
    }
}

void Expression::SymBreakIndexToBindIndex(vec2_t &symbreak_low,
        vec2_t &symbreak_up) const {
    symbreak_low.resize(this->output->out_index.size());
    symbreak_up.resize(this->output->out_index.size());
    if (this->IsTranspose()) {
        /* Transpose symmetry breaking index is with respect to final output
         * therefore the index is the transposed one
         * but the index should be before Transpose in order to be useful
         * because symmetry breaking should be applied when iterating input
         * therefore should map output index to input index
         */
        order_1d_t revert_transpose(this->output->out_index.size());
        order_t out_index = 0;
        for (auto &input_index : this->io_vertex_index) {
            revert_transpose[out_index] = input_index[0];
            out_index++;
        }
        for (auto rule : this->symbreak_index) {
            // assume bind index should be the smaller one
            auto bind_index = revert_transpose[(*rule)[0]];
            for (size_t ith = 1; ith < rule->size(); ith++) {
                auto input_index = revert_transpose[(*rule)[ith]];
                if (input_index < bind_index) {
                    symbreak_up[bind_index].push_back(input_index);
                } else {
                    symbreak_low[input_index].push_back(bind_index);
                }
            }
        }
    } else {
        for (auto rule : this->symbreak_index) {
            // assume bind index should be the smaller one
            auto bind_index = (*rule)[0];
            for (size_t ith = 1; ith < rule->size(); ith++) {
                auto out_index = (*rule)[ith];
                if (out_index < bind_index) {
                    symbreak_up[bind_index].push_back(out_index);
                } else {
                    symbreak_low[out_index].push_back(bind_index);
                }
            }
        }
    }
}

} //namespace abstract
