/*
 * operand.cpp
 *
 *  Created on: 15:19 PM Friday 2023-2-17
 *      Author: Anonymity
 */

#include <cstdlib>          // size_t

#include "include/abstract/operand.hpp"

namespace abstract {

bool Operand::Compare(const Operand *a, const Operand *b) {
    /* sort input to unify function name for execution
     * compare index, smaller goes first (return true)
     * then compare length, longer goes first (return true)
     */
    for (size_t ith = 0;; ith++) {
        if (ith < a->out_index.size()) {
            if (ith < b->out_index.size()) {
                // both in range. compare index
                if (a->out_index[ith] == b->out_index[ith]) {
                    // tie
                    continue;
                }
                return a->out_index[ith] < b->out_index[ith];
            } else {
                // this is longer
                return true;
            }
        } else {
            // other is longer
            return false;
        }
    }
    return true;
}

void Operand::PrintDetail(bool end_of_line) const {
    Print("Operand=" << this << " vertex count=" << this->out_index.size());
    if (this->is_nonedge) {
        Print(" type=non_edge edge_index=");
        PrintArray(this->edge_index, this->edge_index.size());
        Print(" empty=match_all");
    } else if (not this->edge_index.empty()) {
        // must be an input edge
        Print(" type=edge edge_index=");
        PrintArray(this->edge_index, this->edge_index.size());
        Print(" empty=match_none");
    } else {
        /* maps to a materialized result or edge with symmetry breaking
         * and therefore no edge_index
         */
        Print(" type=edge/intermediate");
    }
    if (end_of_line) {
        PrintLine("");
    }
}

}
