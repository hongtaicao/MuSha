/*
 * execution.cpp
 *
 *  Created on: 15:18 PM Friday 2023-2-10
 *      Author: Anonymity
 */

#include "include/abstract/execution.hpp"
#include "include/abstract/expression.hpp"
#include "include/abstract/operand.hpp"

namespace abstract {

// initialize variable
const std::string AllMatchInput = "a";      // non-edge all match
const std::string IndexSeparator = "_";     // separate vertex index
const std::string MarkEdge = "e";           // input edge Operand
const std::string MarkInput = "i";          // input Operand
const std::string MarkNegation = "n";       // negation in join
const std::string MarkSymBreak = "s";       // symmetry breaking rule
const std::string MismatchInput = "x";
const std::string NonedgeAdd = "+";         // non-edge input name

Expression *Execution::NewExpression(Operand *output) {
    // every new Expression must be in the pool and an output maps to it
    Expression *expression = new Expression(output);
    this->expression_1d.push_back(expression);
    this->op_to_expr[output] = expression;
    return expression;
}
Operand *Execution::NewOperand() {
    auto operand = new Operand;
    this->operand_1d.push_back(operand);
    return operand;
}

void Execution::PrintDetail(bool end_of_line) const {
    PrintLCTX("Execution=" << this << " mapping Output_Operand<-Expression=");
    for (auto &pair : this->op_to_expr) {
        Print(pair.first << "<-" << pair.second << " ");
    }
    PrintLine("");
    PrintLine("Execution expression list should execute from the last");
    Print("Final_Output ");
    this->output->PrintDetail(true);
    for (auto *expression : this->expression_1d) {
        expression->PrintDetail(true);
    }
    if (end_of_line) {
        PrintLine("");
    }
}

Execution::Execution() {
    this->output = new Operand;
}

Execution::~Execution() {
    for (auto expr : this->expression_1d) {
        delete expr;
    }
    for (auto operand : this->operand_1d) {
        delete operand;
    }
    delete this->output;
}

}
