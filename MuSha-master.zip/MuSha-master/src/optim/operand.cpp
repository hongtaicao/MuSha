/*
 * operand.cpp
 *
 *  Created on: 8:43 AM Sunday 2022-11-06
 *      Author: Anonymity
 */

#include <algorithm>                    // std::binary_search, std::sort
#include <cassert>
#include <unordered_map>

#include "include/optim/operand.hpp"
#include "include/optim/query.hpp"
#include "include/optim/symbreak/singlenode.hpp"

namespace optim {

// local function
bool CoverRule(order_2d_t &candidate, order_1d_t *a) {
    // whether candidate contain a rule that include a
    for (auto &large_ptr : candidate) {
        order_set_t small_set;
        for (auto &item : (*a)) {
            small_set.insert(item);
        }
        for (auto &item : (*large_ptr)) {
            small_set.erase(item);
        }
        if (small_set.empty()) {
            return true;
        }
    }
    return false;
}

void DeleteContent(order_2d_t &constraint) {
    for (auto &item : constraint) {
        delete item;
    }
}

void SortSymBreak(order_2d_t &rule_1d) {
    /* a rule = (bind order, other order ...)
     * order is also permutation
     * sort other order for comparison purpose
     */
    for (auto &item_ptr : rule_1d) {
        /* the first is the bind order
         * remaining order (permutation) have no order, can be sorted
         */
        std::sort(item_ptr->begin() + 1, item_ptr->end());
    }
    std::sort(rule_1d.begin(), rule_1d.end(),
            Operand::AscSymBreakRuleValueCount);
}

bool TransformRule1d(const Operand *a, const Operand *b, order_2d_t &a_1d) {
    // find permutation that transform a.order -> b.order
    auto index = a->FindSameOrder(b);
    if (index < 0) {
        // does not find the same order
        return false;
    }
    // transform a.constraint using permutation
    auto &mapping = (*a->query->mapping_1d[index]);
    for (auto &ptr_a : a->rule_1d) {
        auto *ptr_new = new order_1d_t;
        for (auto order : (*ptr_a)) {
            // rule value is order the permutation of Query.v_1d
            ptr_new->push_back(mapping[order]);
        }
        a_1d.push_back(ptr_new);
    }
    return true;
}

// class method
bool Operand::AscSymBreakRuleValueCount(const order_1d_t *a,
        const order_1d_t *b) {
    for (size_t i = 0;; i++) {
        if (i < a->size()) {
            if (i < b->size()) {
                if ((*a)[i] < (*b)[i]) {
                    // a value is smaller, a is smaller
                    return true;
                } else if ((*a)[i] > (*b)[i]) {
                    return false;
                }
            } else {
                // b is shorter, b is smaller
                return false;
            }
        } else if (i < b->size()) {
            // a is shorter, a is smaller
            return true;
        }
    }
    return true;
}

void Operand::BuildSymBreak(SingleNode *head) {
    assert(this->rule_1d.empty());
    while (head != nullptr) {
        auto rule_ptr = new order_1d_t;
        for (auto &order : head->rule_1d) {
            rule_ptr->push_back(order);
        }
        this->rule_1d.push_back(rule_ptr);
        head = head->parent;
    }
    this->SortSymBreak();
}

void Operand::ClearSymBreak() {
    DeleteContent(this->rule_1d);
    this->rule_1d.clear();
}

bool Operand::ContainSymBreak(const Operand *other) const {
    if (this->rule_1d.size() >= other->rule_1d.size()) {
        order_2d_t transformed_1d;
        TransformRule1d(other, this, transformed_1d);
        optim::SortSymBreak(transformed_1d);
        /* for each transformed constraint
         * find its super symmetry breaking from this->constraint
         * use bind order to index constraint
         */
        std::unordered_map<order_t, order_2d_t> index_of_super;
        for (auto &a_ptr : this->rule_1d) {
            index_of_super[(*a_ptr)[0]].push_back(a_ptr);
        }
        for (auto &b_ptr : transformed_1d) {
            if (not CoverRule(index_of_super[(*b_ptr)[0]], b_ptr)) {
                DeleteContent(transformed_1d);
                return false;
            }
        }
    }
    return false;
}

// cannot inline
// undefined reference to `optim::Operand::Isomorphic(optim::Operand const*) const'
bool Operand::Isomorphic(const Operand *other) const {
    return this->query->tid == other->query->tid;
}

int Operand::FindSameOrder(const Operand *other) const {
    /* determine if a transpose is needed when using the source
     * two operand use the same Query
     * therefore orders are based on the same Query.v_1d
     * if one order is identical to the other under one mapping
     * then transpose is not needed
     */
    assert(this->query->tid == other->query->tid);
    int index = -1;
    for (auto &mapping : this->query->mapping_1d) {
        // usually the first mapping is identity mapping
        index++;
        bool match = true;
        for (size_t index = 0; index < this->query->v_1d.size(); index++) {
            if ((*mapping)[this->order[index]] != other->order[index]) {
                // check if iso[this.order] == source.order
                match = false;
                break;
            }
        }
        if (match) {
            return index;
        }
    }
    return -1;
}

bool Operand::IsDirectShare(const Operand *other) const {
    /* determine if symmetry breaking rules are the same
     * a symmetry breaking rule is a constraint set
     * each set contains multiple constraint
     * each constraint = (bind order, other order ...)
     * two constraint sets are equivalent
     * 1. the size of the set should be the same
     * 2. for each constraint the bind order should be the same
     * 3. for each constraint other order should form the same set
     * assume the same query
     */
    assert(this->query->tid == other->query->tid);
    order_2d_t transformed_1d;
    if (not TransformRule1d(this, other, transformed_1d)) {
        // cannot find the same vertex order
        return false;
    }
    if (transformed_1d.size() != other->rule_1d.size()) {
        // compare size of constraint set
        DeleteContent(transformed_1d);
        return false;
    }
    // should sort them first and then compare item by item
    optim::SortSymBreak(transformed_1d);
    for (size_t ith = 0; ith < transformed_1d.size(); ith++) {
        // compare if rules are the same size
        const auto a_ptr = transformed_1d[ith];
        const auto b_ptr = other->rule_1d[ith];
        if (a_ptr->size() != b_ptr->size()) {
            DeleteContent(transformed_1d);
            return false;
        }
        // rule content are sorted and therefore can be compared one by one
        for (size_t jth = 0; jth < a_ptr->size(); jth++) {
            if ((*a_ptr)[jth] != (*b_ptr)[jth]) {
                DeleteContent(transformed_1d);
                return false;
            }
        }
    }
    DeleteContent(transformed_1d);
    return true;
}

void Operand::KeepCommonSymBreak(Operand *other) {
    /* each rule is also represented by order, permutation of Query.v_1d
     * therefore rule computation is independent of Operand.order_1d
     * Operand.order_1d is another permutation, to re-order Query.v_1d
     *
     * this->query->tid == other->query->tid
     * and therefore rule comparison can be based on bind order value
     */
    if (this->rule_1d.size() > other->rule_1d.size()) {
        other->KeepCommonSymBreak(this);
        return;
    }
    DPrintCTX("Before\nthis  ");
    this->DebugPrint(true);
    DPrint("other ");
    other->DebugPrint(true);
    // map bind_order the the rule index in rule_1d
    std::unordered_map<order_t, size_t> order_to_ith;
    for (size_t ith = 0; ith < other->rule_1d.size(); ith++) {
        auto &bind_order = (*other->rule_1d[ith])[0];
        if (not order_to_ith.count(bind_order)) {
            order_to_ith[bind_order] = ith;
        }
    }
    // for each transformed rule, find the best match from other->rule_1d
    order_2d_t input_rule_a, input_rule_b;
    for (auto &rule_a : this->rule_1d) {
        // find the best rule_b that are common with rule_a
        auto bind_order = (*rule_a)[0];
        order_1d_t *buffer = new order_1d_t;
        order_1d_t *max_common = new order_1d_t;
        size_t max_common_index = 0;
        if (order_to_ith.count(bind_order)) {
            for (size_t ith_b = order_to_ith[bind_order];
                    ith_b < other->rule_1d.size(); ith_b++) {
                /* rule in rule_1d are sorted and therefore
                 * ith_b can start from order_to_ith[bind_order]
                 */
                order_1d_t *rule_b = other->rule_1d[ith_b];
                if (rule_b == nullptr) {
                    // rule_b can be nullptr if already paired with a rule_a
                    continue;
                }
                if (bind_order != (*rule_b)[0]) {
                    /* only check rule of the same bind index
                     * rule_1d is sorted and therefore remaining rule
                     * cannot match bind_order either
                     */
                    break;
                }
                /* find common index between rule_a and rule_b
                 * buffer, as (rule_a index, common index)
                 * rule_a index is used to construct input rule from rule_a
                 * common index is used to construct input rule from rule_b
                 */
                buffer->clear();
                for (size_t ith = 1; ith < rule_a->size(); ith++) {
                    if (std::binary_search(rule_b->begin() + 1, rule_b->end(),
                            (*rule_a)[ith])) {
                        buffer->push_back(ith);
                        buffer->push_back((*rule_a)[ith]);
                    }
                }
                if (buffer->size() > max_common->size()) {
                    // find rule_b that has more common with rule_a
                    max_common_index = ith_b;
                    std::swap(buffer, max_common);
                }
            }
        }
        if (not max_common->empty()) {
            // create input rule based on max_common
            order_1d_t *new_a = new order_1d_t;
            order_1d_t *new_b = new order_1d_t;
            /* this->rule_1d and transformed_1d match because of no sort
             * this->rule_1d is converted to tranformed_1d to compare rule_b
             * therefore new_a should be created from this->rule_1d
             */
            // bind order
            new_a->push_back((*rule_a)[0]);
            new_b->push_back(bind_order);
            for (size_t ith = 0; ith < max_common->size(); ith += 2) {
                /* parse two values from max_common each time
                 * the first is the rule_a index, the index-th rule
                 * the second is the rule_b index
                 */
                new_a->push_back((*rule_a)[(*max_common)[ith]]);
                new_b->push_back((*max_common)[ith + 1]);
            }
            input_rule_a.push_back(new_a);
            input_rule_b.push_back(new_b);
            /* max_common maps to max_common_index
             * rule_a and max_common are paired
             * should be removed from other->rule_1d
             */
            delete other->rule_1d[max_common_index];
            other->rule_1d[max_common_index] = nullptr;
        }
    }
    // delete both this->rule_1d and other->rule_1d
    this->ClearSymBreak();
    other->ClearSymBreak();
    // copy new rule into input
    this->rule_1d = input_rule_a;
    this->SortSymBreak();
    other->rule_1d = input_rule_b;
    other->SortSymBreak();
    DPrintCTX("After\nthis  ");
    this->DebugPrint(true);
    DPrint("other ");
    other->DebugPrint(true);
}

void Operand::PrintDetail(bool end_of_line) const {
    Print("Operand=" << this << " estimate_size=" << this->estimate_size);
    Print(" vertex order (permutation)=");
    PrintArray(this->order, this->order.size());
    this->query->PrintDetail(false);
    Print(" symmetry breaking (bind order, other order ...)=");
    for (auto &constraint : this->rule_1d) {
        PrintArray(*constraint, constraint->size());
        Print(";");
    }
    if (end_of_line) {
        PrintLine("");
    }
}

void Operand::SortSymBreak() {
    optim::SortSymBreak(this->rule_1d);
}

// cannot inline
// undefined reference
bool Operand::AscQuerySizeIsomorphism::operator()(const Operand *a,
        const Operand *b) const {
    return Query::AscSizeIsomorphism()(a->query, b->query);
}

} // namespace optim
