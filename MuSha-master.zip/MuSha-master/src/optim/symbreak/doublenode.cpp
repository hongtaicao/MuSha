/*
 * doublenode.cpp
 *
 *  Created on: 23:46 PM Saturday 2022-12-03
 *      Author: Anonymity
 */

#include "include/common.hpp"
#include "include/optim/symbreak/doublenode.hpp"
#include "include/optim/symbreak/singlenode.hpp"

namespace optim {

namespace symbreak {

#ifndef NDEBUG
void DebugPrintAll(const DoubleNode *dnode, const std::string &&indent) {
    // print itself and all of its children (top down) with indent
    for (auto &pair : dnode->index_to_node) {
        DPrint(indent << "{" << pair.first);
        pair.second->DebugPrint(false);
        DPrintLine("}");
        symbreak::DebugPrintAll(pair.second, indent + "  ");
    }
}

void DoubleNode::DebugPrint(bool end_of_line) const {
    // print itself as " this=[node_id depth SingleNode]"
    DPrint(this << "=[" << this->node_id << " " << this->depth << " ");
    if (this->constraint == nullptr) {
        DPrint("SingleNode=nullptr");
    } else {
        this->constraint->DebugPrint(false);
    }
    if (end_of_line) {
        DPrintLine("]");
    } else {
        DPrint("]");
    }
}

void DoubleNode::DebugPrintAll() const {
    // print itself and all of its children (top down), the top level
    DPrintLine("{index DoubleNode} start");
    symbreak::DebugPrintAll(this, "");
    DPrintLine("{index DoubleNode} end");
}

void DoubleNode::DebugPrintChain(bool end_of_line) const {
    // print itself and all of its parent (bottom up)
    DPrint("symmetry breaking: DoubleNode=[node_id depth SingleNode]");
    auto head = this;
    while (head != nullptr) {
        DPrint(" ");
        head->DebugPrint(false);
        head = head->parent;
    }
    if (end_of_line) {
        DPrintLine("");
    }
}
#endif

DoubleNode::~DoubleNode() {
    for (auto &pair : this->index_to_node) {
        delete pair.second;
    }
}

} // namespace symbreak

} // namespace optim
