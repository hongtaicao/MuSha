/*
 * symbreak.cpp
 *
 * bind index or bind order
 * a symmetry breaking rule is represented as a list of elements
 * element of a rule is called orders (permutation) or indexes of Query.v_1d
 * rule element is called order (permutation) because it is the same way
 * as Operand.order_1d
 * rule element is also called index because it is used to index Query.v_1d
 * to find the actual vertex that follow the symmetry breaking rule
 *
 *  Created on: 16:43 PM Monday 2022-11-14
 *      Author: Anonymity
 */

#include <cstdlib>          // size_t

#include "include/optim/symbreak/singlenode.hpp"
#include "include/optim/symbreak/symbreak.hpp"
#include "include/utility/config.hpp"

#define INCLUDE_EQUIVALENT_RULE
/* for a 4 vertex star graph (0,1,2,3), 0 be the center vertex
 * one symmetry breaking rule is 1<2<3
 * equivalent rules are 1<3<2, 2<1<3, 2<3<1, 3<1<2, 3<2<1
 * with INCLUDE_EQUIVALENT_RULE defined => 6 results, undefined => 1 result
 */

namespace optim {

namespace symbreak {

#ifdef NDEBUG
#define DPrintAllConstraint(x)  (void (0))
#define DPrintMapping(x)        (void (0))
#else
void DPrintAllConstraint(
        const typename SymBreak::snode_1d_t &query_constraint) {
    size_t count = 0;
    for (auto &snode : query_constraint) {
        DPrint(count++ << ": ");
        snode->DebugPrintChain(true);
    }
    DPrintLine("");
}

void DPrintMapping(const vid_2d_t &mapping_1d) {
    for (const auto &mapping : mapping_1d) {
        DPrintArray(*mapping, mapping->size());
        DPrint(";");
    }
    DPrintLine("");
}
#endif

void SymBreak::Initialize(Config &c, const vid_2d_t &mapping_1d) {
    // generate constraint set
    DPrintCTX("print automorphic mapping of the query=");
    DPrintMapping(mapping_1d);
    if (c.SymmetryBreaking2007()) {
        /* implement 2007 paper
         * Network Motif Discovery Using Subgraph Enumeration and
         * Symmetry-Breaking
         * section 2.2
         * SymmetryConditions:
         * Finds symmetry-breaking conditions for H given H_E, Aut(H)
         */
        /* a rule is a list of order, permutation
         * such that the first vertex, Query.v_1d[order] is bound to
         * the smallest data graph vertex among all others within the same
         */
        paper2007::Generate(0, mapping_1d[0]->size(), mapping_1d, nullptr,
                this->query_constraint, this->constraint_set);
    } else if (c.SymmetryBreakingGraphPi()) {
        /* implement algorithm 1 from a 2020 paper
         * Graphpi High performance graph pattern matching through effective
         * redundancy elimination
         * this algorithm has limitation: generate and verify approach
         * meanwhile, many steps are unclear why they are correct
         */
        /* a permutation group = all isomorphic mapping
         * a permutation = one isomorphic mapping
         * a rule is a list of order, of two vertexes
         * such that the first vertex, Query.v_1d[order] is bound to
         * the smallest data graph vertex among all others
         */
        graphpi::Generate(mapping_1d, nullptr, this->query_constraint,
                this->constraint_set);
    } else {
        PrintLCTX("No symmetry breaking algorithm is specified. Skip.");
    }
    DPrintLCTX("print all possible query_constraint to break symmetry");
    DPrintAllConstraint(this->query_constraint);
}

SymBreak::~SymBreak() {
    for (auto &constraint : this->constraint_set) {
        delete constraint;
    }
}

namespace graphpi {

void Generate(const vid_2d_t &pg, SingleNode *head, snode_1d_t &result,
        snode_set_t &constraint_set) {
    /* GraphPi generate function
     * with several changes
     * permutation group does not include identity permutation
     *
     * this initial algorithm has several issues
     * Why does it rely on disjoint 2-cycles? (line 11)
     * Does eliminating disjoint 2-cycles always lead to a solution?
     * Why does it have to check if a restriction set is valid? (line 21-23)
     */
    for (auto &item : pg) {
        auto &permutation = *item;
        for (size_t index = 0; index < permutation.size(); index++) {
            // iterate the index of vertex
            auto &index_p = permutation[index];
#ifndef INCLUDE_EQUIVALENT_RULE
            if (index >= index_p) {
                /* only explore rules of the same pair once
                 * e.g., (0,1) and (1,0) are considered the same
                 */
                continue;
            }
#endif
            if (index == permutation[index_p]) {
                // find a two cycle
                SingleNode *rule = new SingleNode(head); // connect rule
                constraint_set.insert(rule);
                rule->rule_1d.push_back(index);
                rule->rule_1d.push_back(index_p);
                vid_2d_t remaining_pg;
                for (auto &p : pg) {
                    if (SatisfyConstraint(*p, rule)) {
                        remaining_pg.push_back(p);
                    }
                }
                DPrintCTX("rule set=");
                rule->DebugPrintChain(true);
                DPrintCTX("remaining permutation group size=");
                DPrint(remaining_pg.size() << " permutation=");
                DPrintMapping(remaining_pg);
                if (remaining_pg.size() == 1) {
                    // no more permutation group, save this set of rule_1d
                    result.push_back(rule);
                } else {
                    Generate(remaining_pg, rule, result, constraint_set);
                }
            }
        }
    }
}

bool HasCycle(edge_map_t &edge_map, vid_set_t &vertex_set,
        vid_set_t &visited_set) {
    // DFS traversal based on edge to detect cycles
    for (auto &v : vertex_set) {
        if (visited_set.count(v)) {
            return true;
        }
        visited_set.insert(v);
        if (HasCycle(edge_map, edge_map[v], visited_set)) {
            return true;
        }
        visited_set.erase(v);
    }
    // no cycle detected
    return false;
}

bool SatisfyConstraint(const vid_1d_t &permutation, SingleNode *rule) {
    /* return true if the graph is acyclic
     * algorithm line 24 - 29
     */
    edge_map_t edge_map;
    while (rule != nullptr) {
        auto a = rule->rule_1d[0], b = rule->rule_1d[1];
        edge_map[a].insert(b);
        edge_map[permutation[a]].insert(permutation[b]);
        rule = rule->parent;
    }

    // determine if the directed graph has cycles
    for (auto &vertex_neighbor : edge_map) {
        vid_set_t visited_set;
        visited_set.insert(vertex_neighbor.first);
        if (HasCycle(edge_map, vertex_neighbor.second, visited_set)) {
            return false;
        }
        visited_set.erase(vertex_neighbor.first);
    }
    // no cycle detected
    return true;
}

} // namespace graphpi

namespace paper2007 {

void Generate(size_t bind_index, const size_t size,
        const vid_2d_t &automorphism, SingleNode *head, snode_1d_t &result,
        snode_set_t &constraint_set) {
    // identity automorphism is not included in automorphism
    if (automorphism.size() == 1) {
        if (head != nullptr) {
            result.push_back(head);
        }
        return;
    }
    for (; bind_index < size; bind_index++) {
        SingleNode *rule = nullptr;
        vid_2d_t remaining_automorphism;
        vid_set_t pruned;
        for (auto &mapping : automorphism) {
            auto constraint_index = (*mapping)[bind_index];
#ifdef INCLUDE_EQUIVALENT_RULE
            if (constraint_index == bind_index) {
                // add automorphism satisfying this rule
                remaining_automorphism.push_back(mapping);
            } else {
                // this automorphism is pruned by the constraint
                pruned.insert(constraint_index);
            }
#else
            if (constraint_index > bind_index) {
                // this automorphism is pruned by the constraint
                pruned.insert(constraint_index);
            } else if (constraint_index == bind_index) {
                // add automorphism satisfying this rule
                remaining_automorphism.push_back(mapping);
            } else {
                // this is equivalent to previous constraint. should prune
                pruned.clear();
                break;
            }
#endif
        }
        if (pruned.empty()) {
            // does not find a rule
            remaining_automorphism.clear();
            continue;
        } else {
            // find a rule
            rule = new SingleNode(head);
            constraint_set.insert(rule);
            rule->rule_1d.push_back(bind_index);
            for (auto &item : pruned) {
                rule->rule_1d.push_back(item);
            }
#ifdef INCLUDE_EQUIVALENT_RULE
            Generate(0, size, remaining_automorphism, rule, result,
                    constraint_set);
#else
            Generate(bind_index + 1, size, remaining_automorphism, rule, result,
                    constraint_set);
#endif
        }

    }
}

} // namespace paper2007

} // namespace symbreak

} // namespace optim
