/*
 * hypergeometric.cpp
 *
 *  Created on: 10:50 AM Monday 2022-11-07
 *      Author: Anonymity
 */

#include <cstdlib>          // size_t

#include "include/optim/costmodel/hypergeometric.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/operand.hpp"
#include "include/optim/query.hpp"

namespace optim {

namespace costmodel {

// private
void HyperGeometric::InitializeSizeTable(Operand *operand,
        trie_size_1d_t &size_table) {
    // compute attribute size
    /* size_table key should be permutation of Query.v_1d
     * RootSize() argument should be vertex, v_1d[permutation]
     */
    DPrintCTX("operand=" << operand << " (permutation, size)=");
    size_table.resize(operand->order.size());
    if (size_table.size() > 1) {
        order_t a = operand->order[0], b = operand->order[1];
        vid_t va = operand->query->v_1d[a], vb = operand->query->v_1d[b];
        size_table[operand->order[0]] = this->RootSize(va, vb);
        size_table[operand->order[1]] = this->AverageOutNeighborSize(va, vb);
        DPrint("(" << operand->order[0] << "," << this->RootSize(va, vb));
        DPrint(") (" << operand->order[1] << "," << this->AverageOutNeighborSize(va, vb));
        DPrint(") ");
    }
    for (size_t j = 2; j < operand->order.size(); j++) {
        vid_t va = operand->query->v_1d[operand->order[0]];
        order_t b = operand->order[j];
        vid_t vb = operand->query->v_1d[b];
        double attr_size = this->AverageOutNeighborSize(va, vb);
        // determine the minimum size using all previous edge connection
        for (size_t i = 1; i < j; i++) {
            va = operand->query->v_1d[operand->order[i]];
            double child_size = this->AverageOutNeighborSize(va, vb);
            attr_size = this->ExpectMatchSize(attr_size, child_size);
        }
        DPrint("(" << b << "," << attr_size << ") ");
        size_table[b] = attr_size;
    }
    DPrintLine("");
}

} // namespace costmodel

} // namespace optim
