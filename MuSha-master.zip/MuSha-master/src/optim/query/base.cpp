/*
 * base.cpp
 *
 *  Created on: 23:57 PM Monday 2022-11-07
 *      Author: Anonymity
 */

#include <algorithm>    // std::next_permutation
#include <functional>   // std::hash
#include <vector>

#include "include/optim/query.hpp"
#include "include/optim/query/base.hpp"

namespace optim {

namespace query {

// public
bool Base::IsomorphicTo(Query *a, Query *b) {
    vid_1d_t perm;
    for (size_t i = 0; i < a->v_1d.size(); i++) {
        perm.push_back(i);
    }
    DPrintCTX("add automorphic mapping=");
    do {
        if (this->IsomorphicTo(a, b, perm)) {
            // need a copy, r-value
            b->mapping_1d.push_back(new vid_1d_t(perm.begin(), perm.end()));
            DPrintArray(*b->mapping_1d.back(), b->mapping_1d.back()->size());
            DPrint("; ");
        }
    } while (std::next_permutation(perm.begin(), perm.end()));
    DPrintLine("mapping count=" << b->mapping_1d.size());
    return b->mapping_1d.size() > 0;
}

// private
bool Base::IsomorphicTo(Query *a, Query *b, const vid_1d_t &mapping) {
    // should not call by Query with different sizes
    for (size_t j = 0; j < a->v_1d.size(); j++) {
        auto aj = a->v_1d[mapping[j]];
        auto bj = b->v_1d[j];
        for (size_t i = 0; i < j; i++) {
            if (not this->IsomorphicTo(a, a->v_1d[mapping[i]], aj, b,
                    b->v_1d[i], bj)) {
                // use this-> polymorphism to call Labeled / Unlabeled
                return false;
            }
        }
    }
    return true;
}

Base::Base(edge_map_t &edge_map, const vid_set_t &v_set)
        : Query() {
    // initialize edge_map and vertex_1d
    for (auto &src : v_set) {
        for (auto &dst : edge_map[src]) {
            if (v_set.count(dst)) {
                this->out_edge[src].insert(dst);
            }
        }
    }
    this->v_1d.assign(v_set.begin(), v_set.end());
}

} // namespace query

} // namespace optim
