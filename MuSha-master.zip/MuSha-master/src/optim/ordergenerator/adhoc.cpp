/*
 * adhoc.cpp
 *
 *  Created on: 14:30 PM Monday 2023-5-22
 *      Author: Anonymity
 */

#include <cctype>

#include "include/optim/ordergenerator/adhoc.hpp"
#include "include/optim/ordergenerator/degreelabel.hpp"
#include "include/optim/query.hpp"
#include "include/utility/config.hpp"

namespace optim {

namespace ordergenerator {

void Adhoc::Next() {
    // update state
    size_t head = 0;
    std::string vertex = "";
    this->permutation.clear();
    while (this->index_ < this->order_str_.size()) {
        auto ch = this->order_str_[this->index_];
        if (std::isdigit(ch)) {
            if (this->index_ > 0) {
                auto prev = this->order_str_[this->index_ - 1];
                if (not std::isdigit(prev)) {
                    // head of a vertex
                    head = this->index_;
                }
            }
        } else {
            vertex = this->order_str_.substr(head, this->index_ - head);
            auto permute = this->vertex2permute_[std::stoi(vertex)];
            this->permutation.push_back(permute);
            if (ch == ';') {
                // ; is used to separate multiple ordered vertices
                break;
            }
        }
        this->index_++;
    }
    if (this->permutation.size() == this->order_size_) {
        this->in_range_ = true;
    } else {
        this->in_range_ = false;
    }
}

Adhoc::Adhoc(Config &config, Query &query)
        : index_(0), in_range_(false), order_size_(query.v_1d.size()),
          order_str_(config.Plan()), query_(query) {
    /* assume query plan gives the ordered matching vertex
     * need to parse vertex and then compute the permutation
     */
    if (config.Plan().empty()) {
        PrintLCTX("Plan should be ordered vertices, got empty Plan.");
        SystemExit(-1);
    }
    if (config.Plan().back() != ';') {
        PrintLCTX("Plan should end with the character ';'.");
        SystemExit(-1);
    }
    VertexToPermutation(this->query_, this->vertex2permute_);
    this->Next();
}

} // namespace ordergenerator

} // namespace optim
