/*
 * topologytable.cpp
 *
 *  Created on: 18:56 PM Monday 2022-10-31
 *      Author: Anonymity
 */

#include "include/optim/topologytable.hpp"
#include "include/optim/query.hpp"
#include "include/optim/query/labeled.hpp"
#include "include/optim/query/unlabeled.hpp"
#include "include/utility/config.hpp"

namespace optim {

bool TopologyTable::Index(Query *query) {
    // return true if a new topology
    assert(query->tid == 0);
    assert(query->mapping_1d.size() == 0);
    // a new query whose topology to be identified
    auto &topology_1d = this->hash_to_topology_[query->Hash()];
    for (auto &topology : topology_1d) {
        // mapping should transform topology -> query
        topology->IsomorphicTo(query);
        if (query->mapping_1d.size()) {
            // find an isomorphic query
            query->tid = topology->tid;
            break;
        }
    }
    if (not query->mapping_1d.size()) {
        // this is a new topology, find automorphism of itself
        query->IsomorphicTo(query);
        query->tid = this->topology_table_.size();
        topology_1d.push_back(query);
        this->topology_table_.push_back(query);
        return true;
    }
    return false;
}

TopologyTable::TopologyTable(Config &config) {
    DPrintLCTX("this=" << this << " TopologyTable(Config &)");
    this->topology_table_.push_back(nullptr); // reserved. not valid topology
    Query *query = nullptr;
    if (config.IsLabeled()) {
        query = new query::Labeled(config);
    } else {
        query = new query::Unlabeled(config);
    }
    this->Index(query);
    // should contain two, nullptr topology and the query topology
    assert(this->topology_table_.size() == 2);
}

TopologyTable::~TopologyTable() {
    for (auto &x : this->topology_table_) {
        delete x;
    }
}

} // namespace optim
