/*
 * decomposition.cpp
 *
 *  Created on: 1:38 AM Saturday 2022-11-05
 *      Author: Anonymity
 */

#include "include/optim/topdown/decomposition.hpp"
#include "include/optim/query.hpp"

namespace optim {

namespace topdown {

#ifndef NDEBUG
void Decomposition::DebugPrint(bool end_of_line) const {
    DPrint("Decomposition topology=" << this->topology << " topology id=");
    DPrint(this->topology->tid << " parent-to-subquery indexes=");
    for (const auto &pair : this->p_to_sub_index) {
        DPrint("(" << pair.first << ":" << pair.second << ")");
    }
    if (end_of_line) {
        DPrintLine("");
    } else {
        DPrint(" ");
    }
}
#endif

/* cannot inline, otherwise
 * undefined reference to `optim::topdown::Decomposition::MapParentIndex
 */
void Decomposition::MapParentIndex(const size_t parent_index, Query *query) {
    /* keep track of vertex mapping between the following two
     * query: the original decomposed query
     * this->topology: the topology representation of the above
     * the above two are of the same size
     *
     * parent_index is for Query->v_1d of the large Query
     * need to change it to the index of decomposed Topology->v_1d
     * e.g., parent Query->v_1d=[b,c,d,e], parent_index_1d=[0,1,2,3]
     * decomposed Topology->v_1d=[a,b,c], [a,b,c][1,2,0]=[c,d,e]
     * if parent_index=1, parent vertex=c, and scan parent index 0,1,2,3
     * then skip parent index=0
     * parent index=1, vertex=c, viewed as 0-th parent vertex
     * its corresponding subquery vertex=b, subquery index=1 for v_1d
     */
    // the i-th vertex of parent Query->v_1d
    vid_t ith = this->p_to_sub_index.size();
    /* pick a random (e.g., 0) isomorphic mapping from subquery
     * the i-th index of parent vertex = query->mapping[i-th]
     * parent c (index=0) map to topology b, whose index=[1,2,0][0]=1
     */
    this->p_to_sub_index[parent_index] = query->mapping_1d[0]->at(ith);
}

bool Decomposition::Comparator::operator()(const Decomposition *a,
        const Decomposition *b) const {
    // return true if a attribute should join earlier
    for (auto order : this->topology_order_) {
        if (a->HasParentIndex(order)) {
            if (not b->HasParentIndex(order)) {
                // a joins earlier than b
                return true;
            }
            // both a and b has this vertex, move on to the next
        } else {
            if (b->HasParentIndex(order)) {
                // a does not joins earlier than b
                return false;
            }
        }
    }
    return a < b;
}

} // namespace topdown

} // namespace optim
