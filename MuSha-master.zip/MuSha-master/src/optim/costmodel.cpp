/*
 * costmodel.cpp
 *
 *  Created on: 10:02 AM Monday 2022-11-07
 *      Author: Anonymity
 */

#include <algorithm>
#include <cmath>
#include <cstdlib>          // size_t

#include "include/abstract/execution.hpp"
#include "include/optim/costmodel.hpp"
#include "include/optim/expression.hpp"
#include "include/optim/graph.hpp"
#include "include/optim/operand.hpp"
#include "include/optim/query.hpp"
#include "include/optim/query/base.hpp"
#include "include/utility/graph.hpp"

namespace optim {

void CostModel::GetNonEdgeIndex(const vid_t a, const vid_t b,
        edge_index_1d_t &nonedge) {
    auto vp = ToString2(this->query_->Label(a), this->query_->Label(b)) + " ";
    for (auto &edge_topology_label : this->graph_.EdgeTopologyLabel(vp)) {
        auto label_key = vp + edge_topology_label;
        nonedge.push_back(this->graph_.EdgeIndex(label_key));
    }
}

double CostModel::SelectCost(Expression *expression) {
    /* for each vertex with new constraint
     * 1. divide by the filter factor n!
     * 2. add binary search cost using parent vertex filter factor
     * 3. the initial filter factor is 1.0
     */
    return this->ScanCost(expression->input[0]);
}

double CostModel::TransposeCost(Expression *expression) {
    return this->ScanCost(expression->input[0])
            + expression->output->estimate_size;
}

void CostModel::SetOperandSize(Operand *operand) {
    auto &size_table = this->SizeTable(operand);
    if (size_table.size() != operand->order.size()) {
        this->InitializeSizeTable(operand, size_table);
    }
    if (this->config_.OperandTrieSize()) {
        // operand size is self join result size
        // the minimum join cost
        double trie_width = 1.0;
        for (auto &x : operand->order) {
            trie_width *= size_table[x];
            operand->estimate_size += trie_width;
        }
    } else if (this->config_.OperandTableSize()) {
        operand->estimate_size = operand->order.size();
        for (auto &x : operand->order) {
            operand->estimate_size *= size_table[x];
        }
    }
}

// protected
double CostModel::AverageOutNeighborSize(const vid_t a, const vid_t b) {
    // number of vertex at leaf level
    auto label_key = this->LabelKey(a, b);
    if (this->graph_.HasEdgeIndex(label_key)) {
        // skip double checking HasEdgeIndex
        auto edge_index = this->graph_.EdgeIndex(label_key);
        if (not this->edge_table_.count(edge_index)) {
            this->edge_table_[edge_index] = this->graph_.EdgeSize(edge_index);
        }
        return this->edge_table_[edge_index] / this->graph_.RootSize(edge_index);
    }
    // no match
    if (this->query_->HasEdge(a, b) or this->query_->HasEdge(b, a)) {
        // an edge that does not match
        return 0;
    }
    // a unconnected vertex pair that has no match
    return this->graph_.VertexSize();
}

double CostModel::EdgeSize(const vid_t a, const vid_t b) {
    // number of vertex at leaf level of an edge
    auto label_key = this->LabelKey(a, b);
    if (this->graph_.HasEdgeIndex(label_key)) {
        // match
        auto edge_index = this->graph_.EdgeIndex(label_key);
        if (this->edge_table_.count(edge_index)) {
            return this->edge_table_[edge_index];
        }
        eid_t total = this->graph_.EdgeSize(edge_index);
        this->edge_table_[edge_index] = total;
        return total;
    }
    // no match
    if (this->query_->HasEdge(a, b) or this->query_->HasEdge(b, a)) {
        // an edge that does not match
        return 0;
    }
    // a unconnected vertex pair that has no match
    return this->graph_.VertexSize() * this->graph_.VertexSize();
}

// cannot be inline, otherwise not visible in other cpp files
// undefined reference
vid_t CostModel::RootSize(const vid_t a, const vid_t b) {
    // number of vertex at root level
    auto label_key = this->LabelKey(a, b);
    if (this->graph_.HasEdgeIndex(label_key)) {
        return this->graph_.RootSize(this->graph_.EdgeIndex(label_key));
    }
    // no match
    if (this->query_->HasEdge(a, b) or this->query_->HasEdge(b, a)) {
        // an edge that does not match
        return 0;
    }
    // a unconnected vertex pair that has no match
    return this->graph_.VertexSize();
}

double CostModel::HashTrieJoinCost(Expression *expr) {
    double cost = 0, parent_trie_width = 1.0;
    auto &output_table = this->SizeTable(expr->output);
    for (size_t ith = 0; ith < expr->io_vertex_mapping.size(); ith++) {
        // iterate the pair (input operand index, order) to join
        auto &oo = expr->io_vertex_mapping[ith];
        double hash_loop_size = this->SizeTable(expr->input[oo[0]])[oo[1]];
        for (size_t i = 2; i < oo.size(); i += 2) {
            auto size = this->SizeTable(expr->input[oo[i]])[oo[i + 1]];
            hash_loop_size = std::min(hash_loop_size, size);
        }
        /* for each joined parent trie node
         * need to loop over the child node of the smallest size
         * cost = hash_loop_size
         * for each value of the loop
         * need to check if value exists in other child node
         * cost factor = oo.size() / 2
         * then process child nodes of all parent trie nodes at a depth
         * cost = parent_trie_width * hash_loop_size * oo.size() / 2
         */
        cost += parent_trie_width * hash_loop_size * oo.size() / 2;
        parent_trie_width *= output_table[expr->output->order[ith]];
    }
    return cost;
}

double CostModel::SortTrieJoinCost(Expression *expr) {
    double cost = 0, parent_trie_width = 1.0;
    auto &output_table = this->SizeTable(expr->output);
    for (size_t ith = 0; ith < expr->io_vertex_mapping.size(); ith++) {
        // oo: iterate the pair (input operand index, order) to join
        auto &oo = expr->io_vertex_mapping[ith];
        // initialize max_size, min_size
        double max_size = this->SizeTable(expr->input[oo[0]])[oo[1]];
        double min_size = max_size;
        for (size_t i = 2; i < oo.size(); i += 2) {
            auto size = this->SizeTable(expr->input[oo[i]])[oo[i + 1]];
            max_size = std::max(max_size, size);
            min_size = std::min(min_size, size);
        }
        /* for HyperGeometry Cost Model
         * for a joined parent node, k = oo.size()/2 child nodes are joined
         * each of them can be viewed a single-attribute relation
         * therefore can apply leapfrog triejoin Proposition 3.1
         * to compute the join cost
         * which is a WCOJ over k single-attribute relations
         *
         * estimated child node sizes are given by size table
         * compute the max and min size of these nodes
         *
         * need to further estimate number of parent nodes
         * its number can be estimated as the expected common neighbors
         * over all input relations using hypergeometric distribution
         * input relations often overlap on edges in the join
         * and such edges join on every single value
         * therefore to estimate common neighbors, need to identify
         * distinct edges
         * this process is expensive and we need something faster
         *
         * since we apply branch and bound and we need cost lower bound
         * every output node is a common neighbor
         * therefore its size is the lower bound of common neighbors
         * therefore we can use output parent node size as estimation
         *
         * however, Proposition 3.1 is complexity
         * we need some bounds to estimate the computation cost
         * the log factor has to be at lease 1
         * also consider the number of trie iterators used
         * since a priority queue is used
         * the number of comparision of k trie iterators is log(k)
         * lower bounded at 1
         *
         * for PowerLaw Cost Model
         * due to the above lower bound estimation using output node
         * PowerLaw Cost Model use output node size directly
         * and therefore two Cost Models end up to be the same
         */
        cost += parent_trie_width * min_size
                * (1 + std::max(1.0, std::log(max_size / min_size)))
                * std::max(1.0, std::log(oo.size() / 2.0));
        parent_trie_width *= output_table[expr->output->order[ith]];
    }
    return cost;
}

double CostModel::ScanCost(Operand *operand) {
    double cost = 0;
    double attribute_size = 1.0;
    for (auto &index : operand->order) {
        attribute_size *= this->SizeTable(operand)[index];
        cost += attribute_size;
    }
    return cost;
}

trie_size_1d_t &CostModel::SizeTable(Operand *operand) {
    // order_string require operand->order index topology.v_1d
    std::string order_string;
    for (auto &x : operand->order) {
        order_string += "_" + std::to_string(x);
    }
    return this->size_table_[operand->query->tid][order_string];
}

// private
std::string CostModel::LabelKey(const vid_t a, const vid_t b) {
    // find edge topology label
    std::string label_key;
    if (this->query_->HasEdge(a, b)) {
        if (this->query_->HasEdge(b, a)) {
            label_key = ToString4(this->query_->Label(a),
                    this->query_->Label(b), this->query_->Label(a, b),
                    utility::graph::BidirectedEdgeLabel);
        } else {
            label_key = ToString4(this->query_->Label(a),
                    this->query_->Label(b), this->query_->Label(a, b),
                    utility::graph::OutgoingEdgeLabel);
        }
    } else if (this->query_->HasEdge(b, a)) {
        label_key = ToString4(this->query_->Label(a), this->query_->Label(b),
                this->query_->Label(b, a), utility::graph::IncomingEdgeLabel);
    }
    return label_key;
}

CostModel::CostModel(Config &config, Graph &graph, Query *query, SymBreak &sb)
        : config_(config), graph_(graph), symbreak_(sb), query_(query) {
    // check edge index
    for (auto &v_set : this->query_->base->out_edge) {
        for (auto &b : v_set.second) {
            auto label_key = this->LabelKey(v_set.first, b);
            if (not graph.HasEdgeIndex(label_key)) {
                /* data graph cannot match edge
                 * v_set.first -> b or v_set.first <-> b
                 */
                DPrintCTX("Query has an edge=(" << v_set.first << "," << b);
                DPrintLine(") that does not match the data graph.");
                this->edge_match = false;
                return;
            }
        }
    }
    this->edge_match = true;
}

} // namespace optim
