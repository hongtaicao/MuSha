/*
 * combination.cpp
 *
 *  Created on: 14:08 PM Sunday 2022-11-06
 *      Author: Anonymity
 */

#include "include/algorithm/combination.hpp"

namespace algorithm {

void Combination::Next() {
    this->combination[this->k_]++;
    while (this->combination.back() == this->n_) {
        this->combination.pop_back();
        if (this->combination.empty()) {
            // no more combination
            return;
        }
        this->combination[this->combination.size() - 1]++;
    }
    if (this->combination.back() + this->k_ + 1 - this->combination.size()
            > this->n_) {
        /* check if a combination is feasible
         * each combination is presented in ascending order
         * the last element is at least 1 more than the one before it
         * the last element can have a max value of this->n_
         * suppose the combination has x elements, x = this.combination.size()
         * the max value is y=this.combination.back()
         * to have k=this->k_+1 elements, k-x elements should be added
         * therefore the last value is y+k-x and this can be max this->n_
         */
        // no solution
        this->combination.clear();
        return;
    }
    while (this->combination.size() < this->k_ + 1) {
        this->combination.push_back(this->combination.back() + 1);
    }
}

Combination::Combination(size_t n, size_t k)
        : n_(n - 1), k_(k - 1) {
    if ((n > 0) and (k > 0)) {
        this->combination.push_back(0);
    } else {
        // note this->n_ and this->k_ can overflow and can be invalid
        return;
    }
    while (this->combination.size() < k) {
        this->combination.push_back(this->combination.back() + 1);
    }
}

}
