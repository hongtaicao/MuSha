/*
 * vertexset.cpp
 *
 *  Created on: 18:53 PM Monday 2023-4-17
 *      Author: Anonymity
 */

#include "include/csr/vertexset.hpp"

namespace csr {

/* Initialization
 * "Undefined reference" to declared C++ static member variable
 * https://stackoverflow.com/a/35566023
 * need to be initialized in one source file
 *
 * error: definition of 'csr::VertexSet::MAX_DEGREE' is not in namespace
 * enclosing 'csr::VertexSet'
 */
vid_t VertexSet::MAX_DEGREE = 1;

} // namespace csr
