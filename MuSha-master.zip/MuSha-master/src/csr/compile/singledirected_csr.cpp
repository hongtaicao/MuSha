/*
 * singledirected_csr.cpp
 *
 *  Created on: 14:55 PM 2023-5-23
 *      Author: Anonymity
 */

#include <algorithm>
#include <cstdint>
#include <fstream>
#include <string>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/csr/compile/singledirected_csr.hpp"
#include "include/csr/graph.hpp"
#include "include/csr/neighborset.hpp"
#include "include/csr/vertexset.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace csr {

namespace compile {

namespace singledirected_csr {

// local type
typedef std::vector<vid_t> result_1d_t;
typedef std::vector<result_1d_t> result_2d_t;

// function with Argument as argument and ReturnType as return type
using expression_t = void (*)(const Graph &);
typedef std::unordered_map<std::string, expression_t> expression_map_t;

uint64_t COUNTER;
std::ofstream OUTPUT;

uint64_t After(Config &config, result_2d_t &result) {
#if !defined(COUNTING) and defined(LISTING)
    // counter lines in the output file
    std::ifstream in_file(config.SaveFile());
    return std::count(std::istreambuf_iterator<char>(in_file),
            std::istreambuf_iterator<char>(), '\n');
#elif !defined(COUNTING) and defined(MEMORY)
    return result.size();
#endif
    return COUNTER;
}

bool Before(Config &config) {
    // return status. true: good. false: failure
#if !defined(COUNTING) and defined(LISTING)
    PrintLCTX("LISTING");
    const std::string &out_file = config.SaveFile();
    if (out_file.size()) {
        OUTPUT.open(out_file);
    } else {
        PrintLCTX("LISTING missing argument: " << Config::KeySaveFile);
        return false;
    }
#elif !defined(COUNTING) and defined(MEMORY)
    PrintLCTX("MEMORY");
#else
    PrintLCTX("Default: COUNTING");
    COUNTER = 0;
#endif
    return true;
}

/* local variable name convention
 * b: both in-coming and out-going neighbors
 * d: difference
 * i: intersection
 * n: in-coming neighbor
 * o: out-going neighbor
 * s: less / smaller
 * u: union
 * v: vertex
 */
// size 3
void Cycle3_ba_ca(const Graph &g) {
    /* v0->v1->v2->v0
     */
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0, v0);
        NeighborSet o0 = g.O(v0, v0);
        for (vid_t idx1 = 0; idx1 < o0.size; idx1++) {
            vid_t v1 = o0.Vertex(idx1);
            COUNTER += IntersectSize(n0, g.O(v1), v0);
        }
    }
}

void FeedForward(const Graph &g) {
    /*   v0
     *  /  \
     * v1-> v2
     * v0->v1, v0->v2
     */
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet o0 = g.O(v0);
        for (vid_t idx1 = 0; idx1 < o0.size; idx1++) {
            vid_t v1 = o0.Vertex(idx1);
            COUNTER += IntersectSize(o0, g.O(v1));
        }
    }
}

void Path3(const Graph &g) {
    // v1->v0->v2
    VertexSet o0d1; // neighbor of 0, not neighbor of 1
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet o0 = g.O(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            o0d1.DSet(o0, n1);
            COUNTER += DifferenceSize(o0d1, g.O(v1));
        }
    }
}
void Sink3_cb(const Graph &g) {
    // v1->v0<-v2, symmetry breaking v2<v1
    VertexSet n0d1; // neighbor of 0, not neighbor of 1
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            n0d1.DSet(n0, n1, v1);
            COUNTER += DifferenceSize(n0d1, g.O(v1));
        }
    }
}

void Star3_cb(const Graph &g) {
    // v1<-v0->v2, symmetry breaking v2<v1
    VertexSet o0d1; // neighbor of 0, not neighbor of 1
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet o0 = g.O(v0);
        for (vid_t idx1 = 0; idx1 < o0.size; idx1++) {
            vid_t v1 = o0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            o0d1.DSet(o0, n1, v1);
            COUNTER += DifferenceSize(o0d1, g.O(v1));
        }
    }
}

// size 4
void Bifan_da_cb(const Graph &g) {
    /* v0->v1, v0->v2
     * v3->v1, v3->v2
     */
    VertexSet a0s0, a1s1;
    VertexSet n1n2s0, o0d1s1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet o0 = g.O(v0);
        a0s0.USet(g.N(v0, v0), o0.Less(v0));
        for (vid_t idx1 = 0; idx1 < o0.size; idx1++) {
            vid_t v1 = o0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            a1s1.USet(n1.Less(v1), g.O(v1, v1));
            o0d1s1.DSet(o0, a1s1, v1);
            for (vid_t idx2 = 0; idx2 < o0d1s1.size; idx2++) {
                vid_t v2 = o0d1s1.Vertex(idx2);
                n1n2s0.ISet(n1, g.N(v2), v0);
                COUNTER += DifferenceSize(n1n2s0, a0s0);
            }
        }
    }
}

void Clique4(const Graph &g) {
    /* v0->v2
     * v1->v0, v2
     * v3->v0, v1, v2
     */
    VertexSet o1o3;
    for (vid_t v3 = 0; v3 < g.VertexSize(); v3++) {
        NeighborSet o3 = g.O(v3);
        for (vid_t idx1 = 0; idx1 < o3.size; idx1++) {
            vid_t v1 = o3.Vertex(idx1);
            NeighborSet o1 = g.O(v1);
            o1o3.ISet(o1, o3);
            for (vid_t idx0 = 0; idx0 < o1o3.size; idx0++) {
                vid_t v0 = o1o3.Vertex(idx0);
                COUNTER += IntersectSize(o1o3, g.O(v0));
            }
        }
    }
}

void Cycle4_ba_ca_da(const Graph &g) {
    // v0->v1->v2->v3->v0
    VertexSet a0s0;
    VertexSet a1s0;
    VertexSet d0o1s0;
    VertexSet n0d1o2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0s0 = g.N(v0, v0);
        NeighborSet o0s0 = g.O(v0, v0);
        a0s0.USet(n0s0, o0s0);
        for (vid_t idx1 = 0; idx1 < o0s0.size; idx1++) {
            vid_t v1 = o0s0.Vertex(idx1);
            NeighborSet o1s0 = g.O(v1, v0);
            a1s0.USet(g.N(v1, v0), o1s0);
            d0o1s0.DSet(o1s0, a0s0);
            for (vid_t idx2 = 0; idx2 < d0o1s0.size; idx2++) {
                vid_t v2 = d0o1s0.Vertex(idx2);
                n0d1o2.ISet(n0s0, g.O(v2));
                COUNTER += DifferenceSize(n0d1o2, a1s0);
            }
        }
    }
}

void Path4(const Graph &g) {
    // v3->v1->v0->v2
    VertexSet a0;
    VertexSet a2;
    VertexSet a0a2;
    VertexSet o0d1;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        NeighborSet o0 = g.O(v0);
        a0.USet(n0, o0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            o0d1.DSet(o0, g.N(v1));
            o0d1.DSet(o0d1, g.O(v1));
            for (vid_t idx2 = 0; idx2 < o0d1.size; idx2++) {
                vid_t v2 = o0d1.Vertex(idx2);
                a2.USet(g.N(v2), g.O(v2));
                a0a2.USet(a0, a2);
                COUNTER += DifferenceSize(n1, a0a2);
            }
        }
    }
}

void Sink4_dcb(const Graph &g) {
    // 1,2,3<-0
    VertexSet n0d1s1, n0d1d2s2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            n0d1s1.DSet(n0, g.N(v1), v1);
            n0d1s1.DSet(n0d1s1, g.O(v1));
            for (vid_t idx2 = 0; idx2 < n0d1s1.size; idx2++) {
                vid_t v2 = n0d1s1.Vertex(idx2);
                n0d1d2s2.DSet(n0d1s1, g.N(v2), v2);
                COUNTER += DifferenceSize(n0d1d2s2, g.O(v2));
            }
        }
    }
}

void Star4_dcb(const Graph &g) {
    // 0->1,2,3
    VertexSet o0d1s1, o0d1d2s2;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet o0 = g.O(v0);
        for (vid_t idx1 = 0; idx1 < o0.size; idx1++) {
            vid_t v1 = o0.Vertex(idx1);
            o0d1s1.DSet(o0, g.N(v1), v1);
            o0d1s1.DSet(o0d1s1, g.O(v1));
            for (vid_t idx2 = 0; idx2 < o0d1s1.size; idx2++) {
                vid_t v2 = o0d1s1.Vertex(idx2);
                o0d1d2s2.DSet(o0d1s1, g.N(v2), v2);
                COUNTER += DifferenceSize(o0d1d2s2, g.O(v2));
            }
        }
    }
}

// size 5
void Clique5(const Graph &g) {
    /* 0->2, 0->4
     * 1->0, 1->3
     * 2->1
     * 3->0, 3->2, 3->4
     * 4->1, 4->2
     */
    VertexSet n2o3;
    VertexSet n2o3n4;
    VertexSet o2n3;
    VertexSet o2n3o4;
    for (vid_t v3 = 0; v3 < g.VertexSize(); v3++) {
        NeighborSet o3 = g.O(v3);
        for (vid_t idx2 = 0; idx2 < o3.size; idx2++) {
            vid_t v2 = o3.Vertex(idx2);
            n2o3.ISet(g.N(v2), o3);
            o2n3.ISet(g.O(v2), g.N(v3));
            for (vid_t idx4 = 0; idx4 < n2o3.size; idx4++) {
                vid_t v4 = n2o3.Vertex(idx4);
                n2o3n4.ISet(n2o3, g.N(v4));
                o2n3o4.ISet(o2n3, g.O(v4));
                for (vid_t idx0 = 0; idx0 < n2o3n4.size; idx0++) {
                    vid_t v0 = n2o3n4.Vertex(idx0);
                    COUNTER += IntersectSize(o2n3o4, g.N(v0));
                }
            }
        }
    }
}

void Cycle5_ba_ca_da_ea(const Graph &g) {
    // v0->v1->v2->v3->v4->v0
    VertexSet a0s0, a1s0;
    VertexSet a0s0a1s0;
    VertexSet d0o1d4s0;
    VertexSet n0d1s0;
    VertexSet o2n4s0;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0s0 = g.N(v0, v0);
        NeighborSet o0s0 = g.O(v0, v0);
        a0s0.USet(n0s0, o0s0);
        for (vid_t idx1 = 0; idx1 < o0s0.size; idx1++) {
            vid_t v1 = o0s0.Vertex(idx1);
            NeighborSet n1s0 = g.N(v1, v0);
            NeighborSet o1s0 = g.O(v1, v0);
            a1s0.USet(n1s0, o1s0);
            a0s0a1s0.USet(a0s0, a1s0);
            n0d1s0.DSet(n0s0, a1s0);
            for (vid_t idx4 = 0; idx4 < n0d1s0.size; idx4++) {
                vid_t v4 = n0d1s0.Vertex(idx4);
                NeighborSet n4s0 = g.N(v4, v0);
                d0o1d4s0.DSet(o1s0, a0s0);
                d0o1d4s0.DSet(d0o1d4s0, n4s0);
                d0o1d4s0.DSet(d0o1d4s0, g.O(v4, v0));
                for (vid_t idx2 = 0; idx2 < d0o1d4s0.size; idx2++) {
                    vid_t v2 = d0o1d4s0.Vertex(idx2);
                    NeighborSet o2 = g.O(v2);
                    o2n4s0.ISet(o2, n4s0);
                    COUNTER += DifferenceSize(o2n4s0, a0s0a1s0);
                }
            }
        }
    }
}

void Path5(const Graph &g) {
    // v0->v1->v2->v3->v4
    VertexSet a0, a1, a2;
    VertexSet d0d1d2o3, d1o2, n1d2d3;
    for (vid_t v2 = 0; v2 < g.VertexSize(); v2++) {
        NeighborSet n2 = g.N(v2);
        NeighborSet o2 = g.O(v2);
        a2.USet(n2, o2);
        for (vid_t idx1 = 0; idx1 < n2.size; idx1++) {
            vid_t v1 = n2.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            a1.USet(n1, g.O(v1));
            d1o2.DSet(o2, a1);
            for (vid_t idx3 = 0; idx3 < d1o2.size; idx3++) {
                vid_t v3 = d1o2.Vertex(idx3);
                NeighborSet o3 = g.O(v3);
                n1d2d3.DSet(n1, a2);
                n1d2d3.DSet(n1d2d3, g.N(v3));
                n1d2d3.DSet(n1d2d3, o3);
                for (vid_t idx0 = 0; idx0 < n1d2d3.size; idx0++) {
                    vid_t v0 = n1d2d3.Vertex(idx0);
                    d0d1d2o3.DSet(o3, a1);
                    d0d1d2o3.DSet(d0d1d2o3, a2);
                    d0d1d2o3.DSet(d0d1d2o3, g.N(v0));
                    COUNTER += DifferenceSize(d0d1d2o3, g.O(v0));
                }
            }
        }
    }
}

void Sink5_edcb(const Graph &g) {
    // 1,2,3,4<-0
    VertexSet n0d1s1, n0d1d2s2, n0d1d2d3s3;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            n0d1s1.DSet(n0, g.N(v1), v1);
            n0d1s1.DSet(n0d1s1, g.O(v1));
            for (vid_t idx2 = 0; idx2 < n0d1s1.size; idx2++) {
                vid_t v2 = n0d1s1.Vertex(idx2);
                n0d1d2s2.DSet(n0d1s1, g.N(v2), v2);
                n0d1d2s2.DSet(n0d1d2s2, g.O(v2));
                for (vid_t idx3 = 0; idx3 < n0d1d2s2.size; idx3++) {
                    vid_t v3 = n0d1d2s2.Vertex(idx3);
                    n0d1d2d3s3.DSet(n0d1d2s2, g.N(v3), v3);
                    COUNTER += DifferenceSize(n0d1d2d3s3, g.O(v3));
                }
            }
        }
    }
}

void Star5_edcb(const Graph &g) {
    // 0->1,2,3,4
    VertexSet o0d1s1, o0d1d2s2, o0d1d2d3s3;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet o0 = g.O(v0);
        for (vid_t idx1 = 0; idx1 < o0.size; idx1++) {
            vid_t v1 = o0.Vertex(idx1);
            o0d1s1.DSet(o0, g.N(v1), v1);
            o0d1s1.DSet(o0d1s1, g.O(v1));
            for (vid_t idx2 = 0; idx2 < o0d1s1.size; idx2++) {
                vid_t v2 = o0d1s1.Vertex(idx2);
                o0d1d2s2.DSet(o0d1s1, g.N(v2), v2);
                o0d1d2s2.DSet(o0d1d2s2, g.O(v2));
                for (vid_t idx3 = 0; idx3 < o0d1d2s2.size; idx3++) {
                    vid_t v3 = o0d1d2s2.Vertex(idx3);
                    o0d1d2d3s3.DSet(o0d1d2s2, g.N(v3), v3);
                    COUNTER += DifferenceSize(o0d1d2d3s3, g.O(v3));
                }
            }
        }
    }
}

// size 6
void Clique6(const Graph &g) {
    /* 0->2, 3, 4
     * 1->0, 2
     * 2->4, 5
     * 3->1, 2, 4, 5
     * 4->1
     * 5->0, 1, 4
     */
    VertexSet n2n3, n2n3o5, n2n3n4o5, n2o3o5, o2o3, n2o3o4o5, o2o3o5, n2o5;
    for (vid_t v3 = 0; v3 < g.VertexSize(); v3++) {
        NeighborSet n3 = g.N(v3);
        NeighborSet o3 = g.O(v3);
        for (vid_t idx2 = 0; idx2 < o3.size; idx2++) {
            vid_t v2 = o3.Vertex(idx2);
            NeighborSet n2 = g.N(v2);
            n2n3.ISet(n2, n3);
            o2o3.ISet(g.O(v2), o3);
            for (vid_t idx5 = 0; idx5 < o2o3.size; idx5++) {
                vid_t v5 = o2o3.Vertex(idx5);
                NeighborSet o5 = g.O(v5);
                n2o5.ISet(n2, o5);
                n2n3o5.ISet(n2o5, n3);
                n2o3o5.ISet(n2o5, o3);
                o2o3o5.ISet(o2o3, o5);
                for (vid_t idx4 = 0; idx4 < o2o3o5.size; idx4++) {
                    vid_t v4 = o2o3o5.Vertex(idx4);
                    n2n3n4o5.ISet(n2n3o5, g.N(v4));
                    n2o3o4o5.ISet(n2o3o5, g.O(v4));
                    for (vid_t idx0 = 0; idx0 < n2n3n4o5.size; idx0++) {
                        vid_t v0 = n2n3n4o5.Vertex(idx0);
                        COUNTER += IntersectSize(n2o3o4o5, g.N(v0));
                    }
                }
            }
        }
    }
}

void Cycle6_ba_ca_da_ea_fa(const Graph &g) {
    // 0->1->2->3->4->5->0
    VertexSet d0d1d2n5s0, d0d1o2n4d5s0, d0o1d5s0, n0d1s0;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0s0 = g.N(v0, v0);
        NeighborSet o0s0 = g.O(v0, v0);
        for (vid_t idx1 = 0; idx1 < o0s0.size; idx1++) {
            vid_t v1 = o0s0.Vertex(idx1);
            NeighborSet n1 = g.N(v1);
            NeighborSet o1s0 = g.O(v1, v0);
            n0d1s0.DSet(n0s0, n1);
            n0d1s0.DSet(n0d1s0, o1s0);
            for (vid_t idx5 = 0; idx5 < n0d1s0.size; idx5++) {
                vid_t v5 = n0d1s0.Vertex(idx5);
                NeighborSet n5s0 = g.N(v5, v0);
                NeighborSet o5 = g.O(v5);
                d0o1d5s0.DSet(o1s0, n0s0);
                d0o1d5s0.DSet(d0o1d5s0, o0s0);
                d0o1d5s0.DSet(d0o1d5s0, n5s0);
                d0o1d5s0.DSet(d0o1d5s0, g.O(v5));
                for (vid_t idx2 = 0; idx2 < d0o1d5s0.size; idx2++) {
                    vid_t v2 = d0o1d5s0.Vertex(idx2);
                    NeighborSet o2s0 = g.O(v2, v0);
                    d0d1d2n5s0.DSet(n5s0, n0s0);
                    d0d1d2n5s0.DSet(d0d1d2n5s0, o0s0);
                    d0d1d2n5s0.DSet(d0d1d2n5s0, n1);
                    d0d1d2n5s0.DSet(d0d1d2n5s0, o1s0);
                    d0d1d2n5s0.DSet(d0d1d2n5s0, g.N(v2));
                    d0d1d2n5s0.DSet(d0d1d2n5s0, o2s0);
                    for (vid_t idx4 = 0; idx4 < d0d1d2n5s0.size; idx4++) {
                        vid_t v4 = d0d1d2n5s0.Vertex(idx4);
                        d0d1o2n4d5s0.ISet(o2s0, g.N(v4));
                        d0d1o2n4d5s0.DSet(d0d1o2n4d5s0, n0s0);
                        d0d1o2n4d5s0.DSet(d0d1o2n4d5s0, o0s0);
                        d0d1o2n4d5s0.DSet(d0d1o2n4d5s0, n1);
                        d0d1o2n4d5s0.DSet(d0d1o2n4d5s0, o1s0);
                        d0d1o2n4d5s0.DSet(d0d1o2n4d5s0, n5s0);
                        COUNTER += DifferenceSize(d0d1o2n4d5s0, o5);
                    }
                }
            }
        }
    }
}

void Path6(const Graph &g) {
    // v1->v2->v3->v4->v5->v0
    VertexSet a2, a3, a4, a5;
    VertexSet d0n2d3d4d5, d2o3, d2d3o4, d2d3d4o5;
    for (vid_t v3 = 0; v3 < g.VertexSize(); v3++) {
        NeighborSet n3 = g.N(v3);
        NeighborSet o3 = g.O(v3);
        a3.USet(n3, o3);
        for (vid_t idx2 = 0; idx2 < n3.size; idx2++) {
            vid_t v2 = n3.Vertex(idx2);
            NeighborSet n2 = g.N(v2);
            a2.USet(n2, g.O(v2));
            d2o3.DSet(o3, a2);
            for (vid_t idx4 = 0; idx4 < d2o3.size; idx4++) {
                vid_t v4 = d2o3.Vertex(idx4);
                NeighborSet o4 = g.O(v4);
                a4.USet(g.N(v4), o4);
                d2d3o4.DSet(o4, a2);
                d2d3o4.DSet(d2d3o4, a3);
                for (vid_t idx5 = 0; idx5 < d2d3o4.size; idx5++) {
                    vid_t v5 = d2d3o4.Vertex(idx5);
                    NeighborSet o5 = g.O(v5);
                    a5.USet(g.N(v5), o5);
                    d2d3d4o5.DSet(o5, a2);
                    d2d3d4o5.DSet(d2d3d4o5, a3);
                    d2d3d4o5.DSet(d2d3d4o5, a4);
                    for (vid_t idx0 = 0; idx0 < d2d3d4o5.size; idx0++) {
                        vid_t v0 = d2d3d4o5.Vertex(idx0);
                        d0n2d3d4d5.DSet(n2, a3);
                        d0n2d3d4d5.DSet(d0n2d3d4d5, a4);
                        d0n2d3d4d5.DSet(d0n2d3d4d5, a5);
                        d0n2d3d4d5.DSet(d0n2d3d4d5, g.N(v0));
                        COUNTER += DifferenceSize(d0n2d3d4d5, g.O(v0));
                    }
                }
            }
        }
    }
}

void Sink6_fedcb(const Graph &g) {
    // 1,2,3,4,5<-0, v5<v4<v3<v2<v1
    VertexSet n0d1s1, n0d1d2s2, n0d1d2d3s3, n0d1d2d3d4s4;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet n0 = g.N(v0);
        for (vid_t idx1 = 0; idx1 < n0.size; idx1++) {
            vid_t v1 = n0.Vertex(idx1);
            n0d1s1.DSet(n0, g.N(v1), v1);
            n0d1s1.DSet(n0d1s1, g.O(v1));
            for (vid_t idx2 = 0; idx2 < n0d1s1.size; idx2++) {
                vid_t v2 = n0d1s1.Vertex(idx2);
                n0d1d2s2.DSet(n0d1s1, g.N(v2), v2);
                n0d1d2s2.DSet(n0d1d2s2, g.O(v2));
                for (vid_t idx3 = 0; idx3 < n0d1d2s2.size; idx3++) {
                    vid_t v3 = n0d1d2s2.Vertex(idx3);
                    n0d1d2d3s3.DSet(n0d1d2s2, g.N(v3), v3);
                    n0d1d2d3s3.DSet(n0d1d2d3s3, g.O(v3));
                    for (vid_t idx4 = 0; idx4 < n0d1d2d3s3.size; idx4++) {
                        vid_t v4 = n0d1d2d3s3.Vertex(idx4);
                        n0d1d2d3d4s4.DSet(n0d1d2d3s3, g.N(v4), v4);
                        COUNTER += DifferenceSize(n0d1d2d3d4s4, g.O(v4));
                    }
                }
            }
        }
    }
}

void Star6_fedcb(const Graph &g) {
    // 0->1,2,3,4,5, v5<v4<v3<v2<v1
    VertexSet o0d1s1, o0d1d2s2, o0d1d2d3s3, o0d1d2d3d4s4;
    for (vid_t v0 = 0; v0 < g.VertexSize(); v0++) {
        NeighborSet o0 = g.O(v0);
        for (vid_t idx1 = 0; idx1 < o0.size; idx1++) {
            vid_t v1 = o0.Vertex(idx1);
            o0d1s1.DSet(o0, g.N(v1), v1);
            o0d1s1.DSet(o0d1s1, g.O(v1));
            for (vid_t idx2 = 0; idx2 < o0d1s1.size; idx2++) {
                vid_t v2 = o0d1s1.Vertex(idx2);
                o0d1d2s2.DSet(o0d1s1, g.N(v2), v2);
                o0d1d2s2.DSet(o0d1d2s2, g.O(v2));
                for (vid_t idx3 = 0; idx3 < o0d1d2s2.size; idx3++) {
                    vid_t v3 = o0d1d2s2.Vertex(idx3);
                    o0d1d2d3s3.DSet(o0d1d2s2, g.N(v3), v3);
                    o0d1d2d3s3.DSet(o0d1d2d3s3, g.O(v3));
                    for (vid_t idx4 = 0; idx4 < o0d1d2d3s3.size; idx4++) {
                        vid_t v4 = o0d1d2d3s3.Vertex(idx4);
                        o0d1d2d3d4s4.DSet(o0d1d2d3s3, g.N(v4), v4);
                        COUNTER += DifferenceSize(o0d1d2d3d4s4, g.O(v4));
                    }
                }
            }
        }
    }
}

// define here and compile only once
expression_map_t InitializeQueryPlan() {
    /* hash key follows the AutoMine paper
     * each query plan is executed in v0,v1,v2,v3,v4,... order
     * vertex in the function name is the symmetry breaking, separated by _
     * a maps to v0, b maps to v1, ...
     * cba_da means two symmetry breaking: v2<v1<v0 and v3<v0
     */
    expression_map_t e_map;
    e_map.reserve(100);
    // size 3
    e_map["d-cycle-3"] = Cycle3_ba_ca;
    e_map["d-feed-forward"] = FeedForward;
    e_map["d-path-3"] = Path3;
    e_map["d-sink-3"] = Sink3_cb;
    e_map["d-star-3"] = Star3_cb;
    // size 4
    e_map["d-bifan"] = Bifan_da_cb;
    e_map["d-clique-4"] = Clique4;
    e_map["d-cycle-4"] = Cycle4_ba_ca_da;
    e_map["d-path-4"] = Path4;
    e_map["d-sink-4"] = Sink4_dcb;
    e_map["d-star-4"] = Star4_dcb;
    // size 5
    e_map["d-clique-5"] = Clique5;
    e_map["d-cycle-5"] = Cycle5_ba_ca_da_ea;
    e_map["d-path-5"] = Path5;
    e_map["d-sink-5"] = Sink5_edcb;
    e_map["d-star-5"] = Star5_edcb;
    // size 6
    e_map["d-clique-6"] = Clique6;
    e_map["d-cycle-6"] = Cycle6_ba_ca_da_ea_fa;
    e_map["d-path-6"] = Path6;
    e_map["d-sink-6"] = Sink6_fedcb;
    e_map["d-star-6"] = Star6_fedcb;
    return e_map;
}

// public function
bool ExecuteByQueryName(Config &config, const Graph &g, Logger &logger) {
    // execute query by QueryName. pre-defined plans
    // return status. true: good, false: failure
    if (config.IsLabeled()) {
        // non uniformly labeled graph (directed/undirected)
        PrintLCTX("not support labels. skip.");
        return false;
    } else if (g.LabelSize() == 1) {
        // unlabeled undirected graph
        PrintLCTX("not support undirected edges. skip.");
        return false;
    } else if (g.LabelSize() > 2) {
        // unlabeled directed graph
        PrintLCTX("not support bi-directed edges. skip.");
        return false;
    }
    expression_map_t query_plan = InitializeQueryPlan();
    /* c++ error: qualified-id in declaration before '=' token
     * https://stackoverflow.com/a/55330102
     * should define first
     */
    COUNTER = 0;
    utility::InitializeLoopCounter();
    VertexSet::MAX_DEGREE = g.VertexSize();
    if (query_plan.count(config.QueryName())) {
        if (Before(config)) {
            result_2d_t result_2d;
            const utility::timepoint_t &start = utility::GetTimepoint();
            query_plan[config.QueryName()](g);
            logger.DurationExecutionCompiled = utility::GetDuration(start);
            logger.MatchCount = After(config, result_2d);
            // need to overwrite because listing is not implemented
            logger.MatchCount = COUNTER;
            PrintCTX("DurationExecutionCompiled(s)=");
            Print(logger.DurationExecutionCompiled << " MatchCount=");
            PrintLine(logger.MatchCount);
            utility::PrintLoopCounter(true);
            return true;
        }
    } else {
        PrintLCTX("NotImplemented QueryName=" << config.QueryName());
    }
    return false;
}

} // namespace automine_csr

} // namespace compile

} // namespace csr
