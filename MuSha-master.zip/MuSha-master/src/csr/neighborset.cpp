/*
 * neighborset.cpp
 *
 *  Created on: 12:08 PM Tuesday 2023-4-18
 *      Author: Anonymity
 */

#include "include/csr/neighborset.hpp"

namespace csr {

// public method
NeighborSet NeighborSet::Less(const vid_t up) const {
    // return the set of vertex < up
    if (this->size > 64) {
        vid_t idx_l = 0;
        vid_t idx_r = this->size;
        while (idx_r - idx_l) {
            vid_t idx_t = (idx_l + idx_r) / 2;
            if (this->data[idx_t] < up) {
                idx_l = idx_t + 1;
            } else {
                idx_r = idx_t;
            }
        }
        return NeighborSet(this->data, idx_l);
    } else {
        vid_t idx_l = 0;
        while ((idx_l < this->size) && (this->data[idx_l] < up)) {
            idx_l++;
        }
        return NeighborSet(this->data, idx_l);
    }
}

// private method
vid_t GetSize(const vid_t *array, const vid_t array_size, const vid_t up) {
    // return the size such that data[size-1] < up <= data[size]
    if (array_size > 64) {
        vid_t idx_l = 0;
        vid_t idx_r = array_size;
        while (idx_r > idx_l) {
            vid_t idx_t = (idx_l + idx_r) / 2;
            if (array[idx_t] < up) {
                idx_l = idx_t + 1;
            } else {
                idx_r = idx_t;
            }
        }
        return idx_l;
    } else {
        vid_t idx_l = 0;
        while ((idx_l < array_size) && (array[idx_l] < up)) {
            idx_l++;
        }
        return idx_l;
    }
}

} // namespace csr
