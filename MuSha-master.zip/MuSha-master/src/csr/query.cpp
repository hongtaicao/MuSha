/*
 * query.cpp
 *
 *  Created on: 9:35 AM Sunday 2022-8-28
 *      Author: Anonymity
 */

#include <string>

#include "include/csr/query.hpp"

namespace csr {

Query::Query(bool is_labeled, const std::string &query_file,
        const std::string &label_file) {
    utility::graph::ReadTextGraph(is_labeled, query_file, this->edge_map_,
            this->label_map_);
    utility::graph::ReadTextLabelFile(label_file, this->labelstr_index_);
}

} // namespace csr
