/*
 * config.cpp
 *
 *  Created on: 0:10 Sunday 2022-8-28
 *      Author: Anonymity
 */

#include <algorithm>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <vector>

#include "include/common.hpp"
#include "include/utility/clock.hpp"
#include "include/utility/config.hpp"
#include "include/utility/csv.hpp"
#include "include/utility/logger.hpp"
#include "include/utility/utility.hpp"

namespace utility {

namespace config {

int GetInt(int argc, char *argv[], int &i) {
    i++;
    if (i < argc) {
        return std::stoi(argv[i]);
    } else {
        const std::string key(argv[i - 1]);
        PrintLCTX("missing string value for key [" << key << "]");
        SystemExit(-1);
    }
    return 0;
}

std::string GetString(int argc, char *argv[], int &i) {
    i++;
    if (i < argc) {
        return std::string(argv[i]);
    } else {
        const std::string key(argv[i - 1]);
        PrintLCTX("missing string value for key [" << key << "]");
        SystemExit(-1);
    }
    return "";
}

inline void IsFile(const std::string &key, const std::string &value) {
    if (not utility::IsFile(value)) {
        PrintLCTX("file does not exist [" << key << "=" << value << ']');
        SystemExit(-1);
    }
}

void PrintHeader(int argc, char *argv[], const std::string &current_time) {
    PrintLCTX("start command line at " << current_time);
    // PrintLCTX("compilation time: " << __DATE__ << " " << __TIME__);
    PrintLCTX("compiler (g++) version: " << __VERSION__);
    // PrintLCTX("program version: " << Config::Version);
    Print(std::string(argv[0]));
    for (int i = 1; i < argc; i++) {
        Print(" " << std::string(argv[i]));
    }
    PrintLine("");
}

} // namespace config

void Config::DefaultHeader(string_1d_t &header) const {
    header.clear();
    Logger logger;
    auto log_data = logger.Data();
    for (auto &pair : log_data) {
        header.push_back(pair.first);
    }
    for (auto &pair : this->int_) {
        header.push_back(pair.first);
    }
    for (auto &pair : this->string_) {
        header.push_back(pair.first);
    }
    std::sort(header.begin(), header.end());
}

void Config::PrintParsedArgument() {
    PrintLine("");
    PrintLCTX("============ Program Argument Begin ============");
    string_1d_t key_1d;
    utility::SortMapKey(this->int_, key_1d);
    for (auto &key : key_1d) {
        PrintLCTX("Int [" << key << "=" << this->int_[key] << "]");
    }
    key_1d.clear();
    utility::SortMapKey(this->string_, key_1d);
    for (auto &key : key_1d) {
        PrintLCTX("String [" << key << "=" << this->string_[key] << "]");
    }
    PrintLCTX("============ Program Argument End   ============");
    PrintLine("");
}

void Config::SaveToFile(const Logger &logger) {
    // save Config and Logger to LOG_FILE
    string_1d_t header;
    if (utility::IsFile(this->LOG_FILE)) {
        // read header from LOG_FILE
        std::ifstream infile(this->LOG_FILE);
        std::string line;
        std::getline(infile, line);
        header = ReadCSVRow(line);
        if (header.size() == 1 and header[0].empty()) {
            header.clear();
        }
    }
    if (header.empty()) {
        this->DefaultHeader(header);
        utility::MkFileDir(this->LOG_FILE);
        std::ofstream outfile(this->LOG_FILE);  // default std::ios::trunc
        for (size_t ith = 0; ith < header.size(); ith++) {
            if (ith + 1 == header.size()) {
                outfile << header[ith];
            } else {
                outfile << header[ith] << ",";
            }
        }
        outfile << std::endl;
        PrintLCTX("create result summary file=" << this->LOG_FILE);
    }
    // fill in row
    string_1d_t row;
    row.reserve(header.size());
    auto log_data = logger.Data();
    for (auto &key : header) {
        if (log_data.count(key)) {
            row.push_back(log_data[key]);
        } else if (this->int_.count(key)) {
            row.push_back(std::to_string(this->int_[key]));
        } else if (this->string_.count(key)) {
            row.push_back(this->string_[key]);
        } else {
            row.push_back("");
        }
        row.push_back(",");
    }
    // append log file
    if (row.size()) {
        // remove the trailing ,
        row.pop_back();
        // append logger file
        utility::MkFileDir(this->LOG_FILE);
        std::ofstream outfile(this->LOG_FILE, std::ios::app);
        for (auto &item : row) {
            outfile << item;
        }
        outfile << std::endl;
        PrintLCTX("append result summary file=" << this->LOG_FILE);
    }
}

void Config::SetOutFileName(const std::string &key, const std::string &dataset,
        const std::string &query_name, const std::string &suffix) {
    // override Config::KeySaveFile
    if (this->string_[key] == Config::ValueDataQuery) {
        this->string_[key] = dataset + "-" + query_name + suffix;
    } else if (this->string_[key] == Config::ValueDataQueryDateTime) {
        std::string date_time = utility::replace(__DATE__, ' ', '_') + "-";
        date_time += utility::replace(__TIME__, ':', '_');
        this->string_[key] = dataset + "-" + query_name + "-" + date_time
                + suffix;
    } else if (this->string_[key] == Config::ValueVersionDataQuery) {
        this->string_[key] = Config::Version + "-" + dataset + "-" + query_name
                + suffix;
    } else if (this->string_[key] == Config::ValueVersionDataQueryDateTime) {
        std::string date_time = utility::replace(__DATE__, ' ', '_') + "-";
        date_time += utility::replace(__TIME__, ':', '_');
        this->string_[key] = Config::Version + "-" + dataset + "-" + query_name
                + "-" + date_time + suffix;
    }
}

Config::Config(int argc, char *argv[]) {
    this->string_[Config::KeyDateTime] = GetCurrentTime();
    config::PrintHeader(argc, argv, this->DateTime());
    // set default values
    this->int_[Config::KeyAutomorphism] = 0;    // don't include automorphism
    this->int_[Config::KeyIsLabeled] = 1;       // labeled
    this->int_[Config::KeySampleCount] = 100;
    this->int_[Config::KeySampleRetryCount] = 100;
    this->int_[Config::KeySampleSubgraphSize] = 6;
    this->int_[Config::KeyShareSubquery] = 1;   // enable sharing
    this->string_[Config::KeyAlgorithm] = Config::ValueAutoMineCSR;
    this->string_[Config::KeyCostModel] = Config::ValueHyperGeometry;
    this->string_[Config::KeyExecute] = Config::ValueExecuteCompiled;
    this->string_[Config::KeyGraphStorage] = Config::ValueCSR;
    this->string_[Config::KeyOperandSize] = Config::ValueTrieSize;
    this->string_[Config::KeyOrderGenerator] = Config::ValueNonAutomorphism;
    this->string_[Config::KeySymmetryBreaking] = Config::ValueSymBreak2007;
    // argv_[0]: program name
    // argv_[1]: first argument
    for (int i = 1; i < argc; i++) {
        const std::string key(argv[i]);
        if (key == this->KeyAlgorithm) {
            // data graph, need processing
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyAutomorphism) {
            // include automorphic subgraphs
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyCostModel) {
            // data graph format
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyDataFile) {
            // text data graph, need processing, cannot be empty
            this->string_[key] = config::GetString(argc, argv, i);
            config::IsFile(key, this->string_[key]);
        } else if (key == Config::KeyBinaryDirectory) {
            // data graph directory, post processing folder
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyExecute) {
            // execute on the data graph. default false
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyGraphStorage) {
            // data graph format
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyIsLabeled) {
            // labeled data and query graphs
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeyOperandSize) {
            // how to estimate result size
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyOrderGenerator) {
            // how to generate vertex order
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyPlan) {
            // plan, optional
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeyQueryFile) {
            // query / pattern graph
            this->string_[key] = config::GetString(argc, argv, i);
            config::IsFile(key, this->string_[key]);
        } else if (key == Config::KeyQueryName) {
            // query / pattern graph by name
            // used in AutoMine
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeySampleCount) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySampleInducedSubgraph) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySampleRetryCount) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySampleSubgraphSize) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySaveFile) {
            /* output subgraph in a file. file can be "default"
             * output subgraph count is always provided
             */
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == Config::KeySaveIntermediateFile) {
            /* output subgraph in a file. file can be "default"
             * output subgraph count is always provided
             */
            this->string_[key] = config::GetString(argc, argv, i);
        } else if (key == this->KeyShareSubquery) {
            this->int_[key] = config::GetInt(argc, argv, i);
        } else if (key == Config::KeySymmetryBreaking) {
            this->string_[key] = config::GetString(argc, argv, i);
        } else {
            PrintLCTX("ignore argument [" << key << "]");
        }
    }
    // check necessary parameters
    config::IsFile(Config::KeyDataFile, this->DataFile());
    // set default parameters
    std::string directory;
    std::string file, dataset, extension;
    SplitDirFile(this->DataFile(), directory, file);
    SplitExt(file, dataset, extension);
    if (not this->BinaryDirectory().size()) {
        if (directory.size()) {
            directory += "/";
        } else {
            directory = "./";
        }
        if (dataset.size()) {
            directory += dataset;
        } else {
            directory += extension;
        }
        this->string_[Config::KeyBinaryDirectory] = directory;
    }
    this->string_[Config::KeyLabelFile] = this->BinaryDirectory()
            + "/label.txt";
    std::string query_name;
    if (this->QueryName().size()) {
        query_name = this->QueryName();
    } else {
        SplitDirFile(this->QueryFile(), directory, file);
        SplitExt(file, query_name, extension);
    }
    this->SetOutFileName(Config::KeySaveFile, dataset, query_name, ".txt");
    this->SetOutFileName(Config::KeySaveIntermediateFile, dataset, query_name,
            "-intermediate");
    // display parsed arguments
    this->PrintParsedArgument();
    // Config and Logger cannot collide on data key
    string_1d_t header;
    this->DefaultHeader(header);
    std::unordered_set<std::string> header_set(header.begin(), header.end());
    if (header.size() != header_set.size()) {
        PrintCTX("Config and Logger collide on data key, key list_size=");
        PrintLine(header.size() << " set_size=" << header_set.size());
        Print("current header list=");
        for (auto &item : header) {
            std::cout << item << std::endl;
        }
        SystemExit(-1);
    }
    // parameter check
    if (this->SaveIntermediateFile().size()) {
        if (this->SaveFile() == this->SaveIntermediateFile()) {
            PrintCTX("output file names " << this->SaveFile() << " and ");
            PrintLine(this->SaveIntermediateFile() << " cannot collide.");
            SystemExit(-1);
        }
    }
#ifdef LISTING
    if (this->SaveFile().empty()) {
        PrintLCTX("LISTING requires [" << Config::KeySaveFile << "]");
        SystemExit(-1);
    }
#endif
    if (this->SaveIntermediateFile().size()) {
        /* write config information
         * https://stackoverflow.com/a/10151286
         * redirect std::cout to file and then restore
         *
         * save op_to_ph and abstract::Expression to file
         * then it map optim::Operand -> abstract::Operand -> sorttrie::Node
         */
        utility::MkFileDir(this->SaveIntermediateFile());
        std::ofstream out_file(this->SaveIntermediateFile(), std::ios::app);
        auto coutbuf = std::cout.rdbuf(out_file.rdbuf()); //save and redirect
        config::PrintHeader(argc, argv, this->DateTime());
        this->PrintParsedArgument();
        std::cout.rdbuf(coutbuf);   //reset to standard output again
    }
}

const std::string Config::KeyAlgorithm = "-algorithm";
const std::string Config::KeyAutomorphism = "-automorphism";
const std::string Config::KeyBinaryDirectory = "-binary-directory";
const std::string Config::KeyCostModel = "-cost-model";
const std::string Config::KeyDataFile = "-data-file";
const std::string Config::KeyDateTime = "DateTime";
const std::string Config::KeyExecute = "-execute";
const std::string Config::KeyGraphStorage = "-graph-storage";
const std::string Config::KeyIsLabeled = "-is-labeled";
const std::string Config::KeyLabelFile = "-label-file";
const std::string Config::KeyOperandSize = "-operand-size";
const std::string Config::KeyOrderGenerator = "-order-generator";
const std::string Config::KeyPlan = "-plan";
const std::string Config::KeyQueryFile = "-query-file";
const std::string Config::KeyQueryName = "-query-name";
const std::string Config::KeySampleCount = "-sample-count";
const std::string Config::KeySampleInducedSubgraph = "-sample-induced-subgraph";
const std::string Config::KeySampleRetryCount = "-sample-retry-count";
const std::string Config::KeySampleSubgraphSize = "-sample-subgraph-size";
const std::string Config::KeySaveFile = "-save-file";
const std::string Config::KeySaveIntermediateFile = "-save-intermediate-file";
const std::string Config::KeyShareSubquery = "-share-subquery";
const std::string Config::KeySymmetryBreaking = "-symmetry-breaking";
const std::string Config::ValueAdhoc = "Adhoc";
const std::string Config::ValueAdhocSortTrie = "AdhocSortTrie";
const std::string Config::ValueAutoMineCSR = "AutoMineCSR";
const std::string Config::ValueAutoMineShareTrie = "AutoMineShareTrie";
const std::string Config::ValueAutoMineWCOJ = "AutoMineWCOJ";
const std::string Config::ValueCSR = "CSR";
const std::string Config::ValueDataQuery = "data-query";
const std::string Config::ValueDataQueryDateTime = "data-query-date-time";
const std::string Config::ValueDegreeLabel = "DegreeLabel";
const std::string Config::ValueDisable = "Disable";
const std::string Config::ValueExecuteCompiled = "compiled";
const std::string Config::ValueExecuteDynamic = "dynamic";
const std::string Config::ValueHyperGeometry = "HyperGeometry";
const std::string Config::ValueNonAutomorphism = "NonAutomorphism";
const std::string Config::ValuePowerLaw = "PowerLaw";
const std::string Config::ValueSingleDirectedCSR = "SingleDirectedCSR";
const std::string Config::ValueSortTrie = "SortTrie";
const std::string Config::ValueSymBreak2007 = "SymBreak2007";
const std::string Config::ValueSymBreakGraphPi = "SymBreakGraphPi";
const std::string Config::ValueTableSize = "TableSize";
const std::string Config::ValueTopDown = "TopDown";
const std::string Config::ValueTrieSize = "TrieSize";
const std::string Config::ValueVersionDataQuery = "version-data-query";
const std::string Config::ValueVersionDataQueryDateTime =
        "version-data-query-date-time";

const std::string Config::Version = "v0.1";
const std::string Config::FUNCTION_FILE = Config::Version + "-function.txt";
const std::string Config::LOG_FILE = Config::Version + "-log.csv";

} // namespace utility
