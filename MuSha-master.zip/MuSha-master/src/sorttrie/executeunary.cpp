/*
 * executeunary.cpp
 *
 *  Created on: 22:38 PM Friday 2023-3-10
 *      Author: Anonymity
 */

#include <cassert>

#include "include/abstract/expression.hpp"
#include "include/sorttrie/compile/sorttrie.hpp"
#include "include/sorttrie/executeunary.hpp"
#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/node.hpp"

namespace sorttrie {

// declare primary template
template<unsigned int N>
void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<N> &);

/* declare specialization
 * Specialization must be declared before the first use
 * that would cause implicit instantiation
 * in every translation unit where such use occurs
 *
 * https://stackoverflow.com/a/41757895
 * Function template can be fully specialized
 * and cannot be partially specialized, this is a fact.
 *
 * therefore below is not declare specialization
 * void InsertHashTrie(iterator_1d_t &, compile::HashTrie<2> &);
 * it is just function overloading
 */
void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<2> &);

void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<3> &);

void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<4> &);

void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<5> &);

void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<6> &);

void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<7> &);

void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<8> &);

void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<9> &);

// local function definition that invisible outside
inline void AppendInternalNode(iterator_1d_t &iter_1d, node_1d_t &node_1d) {
    /* should call the ReSize version
     * used by Join and Rename
     */
    node_1d[iter_1d.size() - 1]->Append(iter_1d.back()->Value(),
            *(node_1d[iter_1d.size()]));
}

template<unsigned int N>
void InsertHashTrie(iterator_1d_t &, order_1d_t &, compile::HashTrie<N> &) {
    /* define the primary template
     * primary template should not be instantiated
     * compile time assertion, static_assert does not work
     * static_assert(false, "InsertHashTrie<N> cannot be instantiated.");
     * because it will instantiate at compile time even if it is not called
     * then catch it at runtime
     */
    PrintLCTX("vertex count N supported=[2,9]. get N=" << N);
    SystemExit(-1);
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<2> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()].push_back(
            iter_1d[index_map[1]]->Value());
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<3> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()][iter_1d[index_map[1]]->Value()].push_back(
            iter_1d[index_map[2]]->Value());
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<4> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()][iter_1d[index_map[1]]->Value()][iter_1d[index_map[2]]->Value()].push_back(
            iter_1d[index_map[3]]->Value());
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<5> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()][iter_1d[index_map[1]]->Value()][iter_1d[index_map[2]]->Value()][iter_1d[index_map[3]]->Value()].push_back(
            iter_1d[index_map[4]]->Value());
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<6> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()][iter_1d[index_map[1]]->Value()][iter_1d[index_map[2]]->Value()][iter_1d[index_map[3]]->Value()][iter_1d[index_map[4]]->Value()].push_back(
            iter_1d[index_map[5]]->Value());
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<7> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()][iter_1d[index_map[1]]->Value()][iter_1d[index_map[2]]->Value()][iter_1d[index_map[3]]->Value()][iter_1d[index_map[4]]->Value()][iter_1d[index_map[5]]->Value()].push_back(
            iter_1d[index_map[6]]->Value());
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<8> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()][iter_1d[index_map[1]]->Value()][iter_1d[index_map[2]]->Value()][iter_1d[index_map[3]]->Value()][iter_1d[index_map[4]]->Value()][iter_1d[index_map[5]]->Value()][iter_1d[index_map[6]]->Value()].push_back(
            iter_1d[index_map[7]]->Value());
}

inline void InsertHashTrie(iterator_1d_t &iter_1d, order_1d_t &index_map,
        compile::HashTrie<9> &hashtrie) {
    hashtrie[iter_1d[index_map[0]]->Value()][iter_1d[index_map[1]]->Value()][iter_1d[index_map[2]]->Value()][iter_1d[index_map[3]]->Value()][iter_1d[index_map[4]]->Value()][iter_1d[index_map[5]]->Value()][iter_1d[index_map[6]]->Value()][iter_1d[index_map[7]]->Value()].push_back(
            iter_1d[index_map[8]]->Value());
}

// public method
Node *ExecuteUnary::Result() {
    if (this->iter_1d_.empty()) {
        return this->node_1d_[0];
    }
    if (this->expression_->IsRename()) {
        /* Rename with symmetry breaking
         * direct sharing should be handled in Constructor
         */
        assert(this->expression_->symbreak_index.size());
        while (this->iter_1d_.size()) {
            auto iterator = this->iter_1d_.back();
            this->iter_1d_.pop_back();
            for (; iterator->InRange(); iterator->Next()) {
                this->node_1d_[this->iter_1d_.size()]->Append(
                        iterator->Value());
            }
            delete iterator;
            // move to next Iterator and ensure Iterator has value
            // otherwise backtrack to upper iter_1d
            AppendInternalNode(this->iter_1d_, this->node_1d_);
            this->iter_1d_.back()->Next();
            for (; not this->iter_1d_.back()->InRange();
                    this->iter_1d_.back()->Next()) {
                delete this->iter_1d_.back();
                this->iter_1d_.pop_back();
                if (this->iter_1d_.empty()) {
                    return this->node_1d_[0];
                }
                AppendInternalNode(this->iter_1d_, this->node_1d_);
            }
            // insert back Iterator over children
            this->Initialize(this->iter_1d_.size());
        }
    } else {
        // Transpose without or with symmetry breaking
        if (this->expression_->io_vertex_index.size() == 2) {
            this->node_1d_[0] = this->Transpose<2>();
        } else if (this->expression_->io_vertex_index.size() == 3) {
            this->node_1d_[0] = this->Transpose<3>();
        } else if (this->expression_->io_vertex_index.size() == 4) {
            this->node_1d_[0] = this->Transpose<4>();
        } else if (this->expression_->io_vertex_index.size() == 5) {
            this->node_1d_[0] = this->Transpose<5>();
        } else if (this->expression_->io_vertex_index.size() == 6) {
            this->node_1d_[0] = this->Transpose<6>();
        } else if (this->expression_->io_vertex_index.size() == 7) {
            this->node_1d_[0] = this->Transpose<7>();
        } else if (this->expression_->io_vertex_index.size() == 8) {
            this->node_1d_[0] = this->Transpose<8>();
        } else if (this->expression_->io_vertex_index.size() == 9) {
            this->node_1d_[0] = this->Transpose<9>();
        } else {
            PrintCTX("vertex count for transpose supported=[2,9]. get=");
            PrintLine(this->expression_->io_vertex_index.size());
            SystemExit(-1);
        }
    }
    return this->node_1d_[0];
}

// private
void ExecuteUnary::Initialize(size_t parent_depth) {
    /* find none or all Join till the last attribute
     * either join_1d.empty() or join_1d.size() == depth
     * pass parent_depth=0 to disable Append
     */
    assert(this->iter_1d_.size());
    while (this->iter_1d_.size() < this->depth_) {
        Iterator *next_iter = this->InitializeIndex(this->iter_1d_.size());
        if (next_iter->InRange()) {
            this->iter_1d_.push_back(next_iter);
        } else {
            delete next_iter;
            this->iter_1d_.back()->Next();
            for (; not this->iter_1d_.back()->InRange();
                    this->iter_1d_.back()->Next()) {
                delete this->iter_1d_.back();
                this->iter_1d_.pop_back();
                if (this->iter_1d_.empty()) {
                    // explored all possible Join and no more result
                    return;
                }
                if (this->iter_1d_.size() < parent_depth) {
                    /* Append subtree when a new parent Node is reached
                     * and is moving to Next()
                     * passing parent_depth = 0 can disable Append
                     * this is used for the initialization
                     */
                    parent_depth = this->iter_1d_.size();
                    AppendInternalNode(this->iter_1d_, this->node_1d_);
                }
            }
        }
    }
}

Iterator *ExecuteUnary::InitializeIndex(size_t out_index) const {
    vid_t low = 0, up = this->vertex_size_;
    for (auto &index : this->symbreak_low_[out_index]) {
        low = std::max(low, this->iter_1d_[index]->Value());
    }
    for (auto &index : this->symbreak_up_[out_index]) {
        up = std::min(up, this->iter_1d_[index]->Value());
    }
    const Node *node;
    if (out_index) {
        node = this->iter_1d_[out_index - 1]->GetNode();
    } else {
        node = this->in_;
    }
    if (low > 0) {
        if (up < this->vertex_size_) {
            return new Iterator(low, node, up);
        } else {
            return new Iterator(low, node);
        }
    } else if (up < this->vertex_size_) {
        return new Iterator(node, up);
    } else {
        return new Iterator(node);
    }
}

template<unsigned int N>
Node *ExecuteUnary::Transpose() {
    // note the index now is input_index
    order_1d_t index_map(this->expression_->io_vertex_index.size());
    for (size_t ith = 0; ith < this->depth_; ith++) {
        index_map[ith] = this->expression_->io_vertex_index[ith][0];
    }
    compile::HashTrie<N> hashtrie;
    while (this->iter_1d_.size()) {
        auto iterator = this->iter_1d_.back();
        for (; iterator->InRange(); iterator->Next()) {
            InsertHashTrie(this->iter_1d_, index_map, hashtrie);
        }
        delete iterator;
        this->iter_1d_.pop_back();
        // move to next Iterator and ensure Iterator has value
        // otherwise backtrack to upper iter_1d
        this->iter_1d_.back()->Next();
        for (; not this->iter_1d_.back()->InRange();
                this->iter_1d_.back()->Next()) {
            delete this->iter_1d_.back();
            this->iter_1d_.pop_back();
            if (this->iter_1d_.empty()) {
                // can use function because it executes only once
                return compile::BuildSortTrie(hashtrie);
            }
        }
        // insert back Iterator over children
        this->Initialize(this->iter_1d_.size());
    }
    return compile::BuildSortTrie(hashtrie);
}

ExecuteUnary::ExecuteUnary(const Expression *expression, Node *node,
        const vid_t vertex_size)
        : expression_(expression), in_(node), depth_(this->in_->Depth()),
          vertex_size_(vertex_size) {
    if (this->expression_->IsRename()) {
        if (this->expression_->symbreak_index.empty()) {
            // direct sharing case
            this->node_1d_.push_back(node);
            return;
        }
    }
    this->expression_->SymBreakIndexToBindIndex(this->symbreak_low_,
            this->symbreak_up_);
    Iterator *next_iter = this->InitializeIndex(0);
    if (next_iter->InRange()) {
        this->iter_1d_.push_back(next_iter);
        InitializeNode1d(this->depth_, this->node_1d_, this->vertex_size_);
        this->Initialize(0);
    } else {
        delete next_iter;
    }
    if (this->node_1d_.empty()) {
        this->node_1d_.push_back(new Node(0));
    }
}

ExecuteUnary::~ExecuteUnary() {
    for (auto &iterator : this->iter_1d_) {
        delete iterator;
    }
    // the 0-th Node is the result Node and other Node should be released
    for (size_t ith = 1; ith < this->node_1d_.size(); ith++) {
        delete this->node_1d_[ith];
    }
}

} // namespace sorttrie
