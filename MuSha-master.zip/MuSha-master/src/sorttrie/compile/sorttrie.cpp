/*
 * sorttrie.cpp
 *
 *  Created on: Thursday 2:09 AM 2023-2-16
 *      Author: Anonymity
 */

#include "include/sorttrie/compile/sorttrie.hpp"
#include "include/sorttrie/node.hpp"

namespace sorttrie {

namespace compile {

template<typename map_T>
void SortMapKey(const map_T &map, vid_1d_t &key_1d) {
    for (auto &pair : map) {
        key_1d.push_back(pair.first);
    }
    std::sort(key_1d.begin(), key_1d.end());
}

Node *BuildSortTrie(HashTrie<2> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &vec = map0[key0];
        std::sort(vec.begin(), vec.end());
        for (auto &value : vec) {
            node1->Append(value);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

Node *BuildSortTrie(HashTrie<3> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &map1 = map0[key0];
        vid_1d_t key1_1d;
        key1_1d.reserve(map1.size());
        SortMapKey(map1, key1_1d);
        for (auto &key1 : key1_1d) {
            Node *node2 = new Node(map1[key1].size());
            auto &vec = map1[key1];
            std::sort(vec.begin(), vec.end());
            for (auto &value : vec) {
                node2->Append(value);
            }
            node1->Append(key1, node2);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

Node *BuildSortTrie(HashTrie<4> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &map1 = map0[key0];
        vid_1d_t key1_1d;
        key1_1d.reserve(map1.size());
        SortMapKey(map1, key1_1d);
        for (auto &key1 : key1_1d) {
            Node *node2 = new Node(map1[key1].size());
            auto &map2 = map1[key1];
            vid_1d_t key2_1d;
            key2_1d.reserve(map2.size());
            SortMapKey(map2, key2_1d);
            for (auto &key2 : key2_1d) {
                Node *node3 = new Node(map2[key2].size());
                auto &vec = map2[key2];
                std::sort(vec.begin(), vec.end());
                for (auto &value : vec) {
                    node3->Append(value);
                }
                node2->Append(key2, node3);
            }
            node1->Append(key1, node2);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

Node *BuildSortTrie(HashTrie<5> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &map1 = map0[key0];
        vid_1d_t key1_1d;
        key1_1d.reserve(map1.size());
        SortMapKey(map1, key1_1d);
        for (auto &key1 : key1_1d) {
            Node *node2 = new Node(map1[key1].size());
            auto &map2 = map1[key1];
            vid_1d_t key2_1d;
            key2_1d.reserve(map2.size());
            SortMapKey(map2, key2_1d);
            for (auto &key2 : key2_1d) {
                Node *node3 = new Node(map2[key2].size());
                auto &map3 = map2[key2];
                vid_1d_t key3_1d;
                key3_1d.reserve(map3.size());
                SortMapKey(map3, key3_1d);
                for (auto &key3 : key3_1d) {
                    Node *node4 = new Node(map3[key3].size());
                    auto &vec = map3[key3];
                    std::sort(vec.begin(), vec.end());
                    for (auto &value : vec) {
                        node4->Append(value);
                    }
                    node3->Append(key3, node4);
                }
                node2->Append(key2, node3);
            }
            node1->Append(key1, node2);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

Node *BuildSortTrie(HashTrie<6> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &map1 = map0[key0];
        vid_1d_t key1_1d;
        key1_1d.reserve(map1.size());
        SortMapKey(map1, key1_1d);
        for (auto &key1 : key1_1d) {
            Node *node2 = new Node(map1[key1].size());
            auto &map2 = map1[key1];
            vid_1d_t key2_1d;
            key2_1d.reserve(map2.size());
            SortMapKey(map2, key2_1d);
            for (auto &key2 : key2_1d) {
                Node *node3 = new Node(map2[key2].size());
                auto &map3 = map2[key2];
                vid_1d_t key3_1d;
                key3_1d.reserve(map3.size());
                SortMapKey(map3, key3_1d);
                for (auto &key3 : key3_1d) {
                    Node *node4 = new Node(map3[key3].size());
                    auto &map4 = map3[key3];
                    vid_1d_t key4_1d;
                    key4_1d.reserve(map4.size());
                    SortMapKey(map4, key4_1d);
                    for (auto &key4 : key4_1d) {
                        Node *node5 = new Node(map4[key4].size());
                        auto &vec = map4[key4];
                        std::sort(vec.begin(), vec.end());
                        for (auto &value : vec) {
                            node5->Append(value);
                        }
                        node4->Append(key4, node5);
                    }
                    node3->Append(key3, node4);
                }
                node2->Append(key2, node3);
            }
            node1->Append(key1, node2);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

Node *BuildSortTrie(HashTrie<7> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &map1 = map0[key0];
        vid_1d_t key1_1d;
        key1_1d.reserve(map1.size());
        SortMapKey(map1, key1_1d);
        for (auto &key1 : key1_1d) {
            Node *node2 = new Node(map1[key1].size());
            auto &map2 = map1[key1];
            vid_1d_t key2_1d;
            key2_1d.reserve(map2.size());
            SortMapKey(map2, key2_1d);
            for (auto &key2 : key2_1d) {
                Node *node3 = new Node(map2[key2].size());
                auto &map3 = map2[key2];
                vid_1d_t key3_1d;
                key3_1d.reserve(map3.size());
                SortMapKey(map3, key3_1d);
                for (auto &key3 : key3_1d) {
                    Node *node4 = new Node(map3[key3].size());
                    auto &map4 = map3[key3];
                    vid_1d_t key4_1d;
                    key4_1d.reserve(map4.size());
                    SortMapKey(map4, key4_1d);
                    for (auto &key4 : key4_1d) {
                        Node *node5 = new Node(map4[key4].size());
                        auto &map5 = map4[key4];
                        vid_1d_t key5_1d;
                        key5_1d.reserve(map5.size());
                        SortMapKey(map5, key5_1d);
                        for (auto &key5 : key5_1d) {
                            Node *node6 = new Node(map5[key5].size());
                            auto &vec = map5[key5];
                            std::sort(vec.begin(), vec.end());
                            for (auto &value : vec) {
                                node6->Append(value);
                            }
                            node5->Append(key5, node6);
                        }
                        node4->Append(key4, node5);
                    }
                    node3->Append(key3, node4);
                }
                node2->Append(key2, node3);
            }
            node1->Append(key1, node2);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

Node *BuildSortTrie(HashTrie<8> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &map1 = map0[key0];
        vid_1d_t key1_1d;
        key1_1d.reserve(map1.size());
        SortMapKey(map1, key1_1d);
        for (auto &key1 : key1_1d) {
            Node *node2 = new Node(map1[key1].size());
            auto &map2 = map1[key1];
            vid_1d_t key2_1d;
            key2_1d.reserve(map2.size());
            SortMapKey(map2, key2_1d);
            for (auto &key2 : key2_1d) {
                Node *node3 = new Node(map2[key2].size());
                auto &map3 = map2[key2];
                vid_1d_t key3_1d;
                key3_1d.reserve(map3.size());
                SortMapKey(map3, key3_1d);
                for (auto &key3 : key3_1d) {
                    Node *node4 = new Node(map3[key3].size());
                    auto &map4 = map3[key3];
                    vid_1d_t key4_1d;
                    key4_1d.reserve(map4.size());
                    SortMapKey(map4, key4_1d);
                    for (auto &key4 : key4_1d) {
                        Node *node5 = new Node(map4[key4].size());
                        auto &map5 = map4[key4];
                        vid_1d_t key5_1d;
                        key5_1d.reserve(map5.size());
                        SortMapKey(map5, key5_1d);
                        for (auto &key5 : key5_1d) {
                            Node *node6 = new Node(map5[key5].size());
                            auto &map6 = map5[key5];
                            vid_1d_t key6_1d;
                            key6_1d.reserve(map6.size());
                            SortMapKey(map6, key6_1d);
                            for (auto &key6 : key6_1d) {
                                Node *node7 = new Node(map6[key6].size());
                                auto &vec = map6[key6];
                                std::sort(vec.begin(), vec.end());
                                for (auto &value : vec) {
                                    node7->Append(value);
                                }
                                node6->Append(key6, node7);
                            }
                            node5->Append(key5, node6);
                        }
                        node4->Append(key4, node5);
                    }
                    node3->Append(key3, node4);
                }
                node2->Append(key2, node3);
            }
            node1->Append(key1, node2);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

Node *BuildSortTrie(HashTrie<9> &map0) {
    vid_1d_t key0_1d;
    key0_1d.reserve(map0.size());
    SortMapKey(map0, key0_1d);
    Node *node0 = new Node(key0_1d.size());
    for (auto &key0 : key0_1d) {
        Node *node1 = new Node(map0[key0].size());
        auto &map1 = map0[key0];
        vid_1d_t key1_1d;
        key1_1d.reserve(map1.size());
        SortMapKey(map1, key1_1d);
        for (auto &key1 : key1_1d) {
            Node *node2 = new Node(map1[key1].size());
            auto &map2 = map1[key1];
            vid_1d_t key2_1d;
            key2_1d.reserve(map2.size());
            SortMapKey(map2, key2_1d);
            for (auto &key2 : key2_1d) {
                Node *node3 = new Node(map2[key2].size());
                auto &map3 = map2[key2];
                vid_1d_t key3_1d;
                key3_1d.reserve(map3.size());
                SortMapKey(map3, key3_1d);
                for (auto &key3 : key3_1d) {
                    Node *node4 = new Node(map3[key3].size());
                    auto &map4 = map3[key3];
                    vid_1d_t key4_1d;
                    key4_1d.reserve(map4.size());
                    SortMapKey(map4, key4_1d);
                    for (auto &key4 : key4_1d) {
                        Node *node5 = new Node(map4[key4].size());
                        auto &map5 = map4[key4];
                        vid_1d_t key5_1d;
                        key5_1d.reserve(map5.size());
                        SortMapKey(map5, key5_1d);
                        for (auto &key5 : key5_1d) {
                            Node *node6 = new Node(map5[key5].size());
                            auto &map6 = map5[key5];
                            vid_1d_t key6_1d;
                            key6_1d.reserve(map6.size());
                            SortMapKey(map6, key6_1d);
                            for (auto &key6 : key6_1d) {
                                Node *node7 = new Node(map6[key6].size());
                                auto &map7 = map6[key6];
                                vid_1d_t key7_1d;
                                key7_1d.reserve(map7.size());
                                SortMapKey(map7, key7_1d);
                                for (auto &key7 : key7_1d) {
                                    Node *node8 = new Node(map7[key7].size());
                                    auto &vec = map7[key7];
                                    std::sort(vec.begin(), vec.end());
                                    for (auto &value : vec) {
                                        node8->Append(value);
                                    }
                                    node7->Append(key7, node8);
                                }
                                node6->Append(key6, node7);
                            }
                            node5->Append(key5, node6);
                        }
                        node4->Append(key4, node5);
                    }
                    node3->Append(key3, node4);
                }
                node2->Append(key2, node3);
            }
            node1->Append(key1, node2);
        }
        node0->Append(key0, node1);
    }
    return node0;
}

} // namespace compile

} // namespace sorttrie
