/*
 * join1.cpp
 *
 *  Created on: 2:03 AM Wednesday 2022-9-14
 *      Author: Anonymity
 */

#include "include/sorttrie/join/join1.hpp"

namespace sorttrie {

namespace join {

void Join1::Negate() {
    // joined value cannot be in the negation leaf level
    while (this->InRange() and (not this->pool1_.empty())
            and (this->pool1_.top()->Value() <= this->Value())) {
        // can potentially join on the negation value
        auto top = this->pool1_.top();
        this->pool1_.pop();
        if (top->GreaterEqual(this->Value())->InRange()) {
            this->pool1_.push(top);
            if (this->pool1_.top()->Value() == this->Value()) {
                // join on a negation value and therefore try Next() value
                Join::Next();
            }
        }
    }
}

Join1::Join1(Iterator **iter, vid_t size, Iterator **iter1, vid_t size1)
        : Join(iter, size), iterator1_(iter1), size1_(size1) {
    // negation is not initialized. does not check negation
    DPrintLCTX("**iterator1=" << iter1 << " size1=" << size1);
    DPrintIterator(iter1, size1);
    for (vid_t i = 0; i < size1; i++) {
        if (iter1[i]->InRange()) {
            this->pool1_.push(iter1[i]);
        }
    }
    this->Negate();
}

Join1::~Join1() {
    for (size_type i = 0; i < this->size1_; i++) {
        delete this->iterator1_[i];
    }
}

} // namespace join

} // namespace sorttrie
