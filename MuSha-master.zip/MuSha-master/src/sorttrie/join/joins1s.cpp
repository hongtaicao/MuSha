/*
 * joins1s.cpp
 *
 *  Created on: 13:30 PM Thursday 2023-3-2
 *      Author: Anonymity
 */

#include "include/sorttrie/join/joins1s.hpp"

namespace sorttrie {

namespace join {

void JoinS1S::Negate() {
    // joined value cannot be in the negation leaf level
    while (this->InRange() and this->iterator1_->Match(this->Value())) {
        // join on a negation value and therefore try Next() value
        JoinS::Next();
    }
}

} // namespace join

} // namespace sorttrie
