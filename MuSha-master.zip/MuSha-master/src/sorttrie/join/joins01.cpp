/*
 * joins01.cpp
 *
 *  Created on: 12:58 PM Thursday 2023-3-2
 *      Author: Anonymity
 */

#include "include/sorttrie/join/joins01.hpp"

namespace sorttrie {

namespace join {

JoinS01::~JoinS01() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
