/*
 * join01t.cpp
 *
 *  Created on: 3:34 AM Friday 2023-3-3
 *      Author: Anonymity
 */

#include "include/sorttrie/join/join01t.hpp"

namespace sorttrie {

namespace join {

Join01T::~Join01T() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
