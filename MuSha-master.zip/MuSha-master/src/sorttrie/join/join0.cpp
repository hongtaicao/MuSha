/*
 * join0.cpp
 *
 *  Created on: 2:02 AM Wednesday 2022-9-14
 *      Author: Anonymity
 */

#include "include/sorttrie/join/join0.hpp"

namespace sorttrie {

namespace join {

Join0::~Join0() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
