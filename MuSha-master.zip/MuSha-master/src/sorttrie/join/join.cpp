/*
 * join.cpp
 *
 *  Created on: 3:47 Wednesday 2022-9-7
 *      Author: Anonymity
 */

#include "include/sorttrie/join/join.hpp"

namespace sorttrie {

namespace join {

void Join::Next() {
    /*
     * input state
     * this->InRange() == True
     * this->pool_.top()->Value() == this->max_value_
     *
     * output state
     * case 1:
     * this->InRange() == False
     *
     * case 2:
     * this->InRange() == True
     * this->pool_.top()->Value() == this->max_value_
     */

    Iterator *it = this->pool_.top();
    this->pool_.pop();
    it->Next();
    if (not it->InRange()) {
        return;
    }
    this->join_value_ = std::max(this->join_value_, it->Value());
    this->pool_.push(it);
    while (this->pool_.top()->Value() < this->join_value_) {
        // the smallest value != join_value_ and therefore is not a join
        Iterator *it = this->pool_.top();
        this->pool_.pop();
        it->GreaterEqual(this->join_value_);
        if (it->InRange()) {
            this->pool_.push(it);
            this->join_value_ = std::max(this->join_value_, it->Value());
        } else {
            // this->InRange() will return false
            return;
        }
    }
}

Join::Join(Iterator **iterator, vid_t size)
        : join_value_(0), iterator_(iterator), size_(size) {
    // find the first join value
    DPrintLCTX("**iterator=" << iterator << " size=" << size);
    DPrintIterator(iterator, size);
    for (size_type i = 0; i < this->size_; i++) {
        if (not this->iterator_[i]->InRange()) {
            return;
        }
        this->pool_.push(this->iterator_[i]);
        this->join_value_ = std::max(this->join_value_,
                this->iterator_[i]->Value());
    }
    if (this->pool_.top()->Value() < this->join_value_) {
        this->Next();
    }
    /* after construction
     * if this->InRange(), then the first join value is already found
     * otherwise out of range
     */
}

/* https://stackoverflow.com/a/25797332
 * virtual keyword can be used only inside class definition
 */
Join::~Join() {
    for (size_type i = 0; i < this->size_; i++) {
        delete this->iterator_[i];
    }
}

} // namespace join

} // namespace sorttrie
