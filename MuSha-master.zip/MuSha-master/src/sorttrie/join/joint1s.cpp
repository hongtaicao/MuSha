/*
 * joint1s.cpp
 *
 *  Created on: 2:09 AM Friday 2023-3-3
 *      Author: Anonymity
 */

#include "include/sorttrie/join/joint1s.hpp"

namespace sorttrie {

namespace join {

void JoinT1S::Negate() {
    // joined value cannot be in the negation leaf level
    while (this->InRange() and this->iterator1_->Match(this->Value())) {
        // join on a negation value and therefore try Next() value
        JoinT::Next();
    }
}

} // namespace join

} // namespace sorttrie
