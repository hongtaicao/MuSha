/*
 * joint.cpp
 *
 *  Created on: 17:33 PM Wednesday 2023-3-1
 *      Author: Anonymity
 */

#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/join/joint.hpp"

namespace sorttrie {

namespace join {

void JoinT::MatchValue() {
    while (this->InRange()) {
        if (this->iterator_a_->Value() < this->iterator_b_->Value()) {
            this->iterator_a_->GreaterEqual(this->iterator_b_->Value());
        } else if (this->iterator_a_->Value() > this->iterator_b_->Value()) {
            this->iterator_b_->GreaterEqual(this->iterator_a_->Value());
        } else {
            return;
        }
    }
}

} // namespace join

} // namespace sorttrie
