/*
 * joint01s.cpp
 *
 *  Created on: 2:42 AM Friday 2023-3-3
 *      Author: Anonymity
 */

#include "include/sorttrie/join/joint01s.hpp"

namespace sorttrie {

namespace join {

JoinT01S::~JoinT01S() {
    for (size_type i = 0; i < this->size0_; i++) {
        delete this->iterator0_[i];
    }
}

} // namespace join

} // namespace sorttrie
