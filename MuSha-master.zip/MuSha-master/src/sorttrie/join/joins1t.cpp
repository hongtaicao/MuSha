/*
 * joins1t.cpp
 *
 *  Created on: 13:44 PM Thursday 2023-3-2
 *      Author: Anonymity
 */

#include "include/sorttrie/join/joins1t.hpp"

namespace sorttrie {

namespace join {

void JoinS1T::Negate() {
    // joined value cannot be in the negation leaf level
    while (this->InRange()
            and (this->iter1_a_->Match(this->Value())
                    or this->iter1_b_->Match(this->Value()))) {
        // join on a negation value
        JoinS::Next();
    }
}

} // namespace join

} // namespace sorttrie
