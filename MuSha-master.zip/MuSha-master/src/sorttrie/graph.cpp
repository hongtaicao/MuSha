/*
 * graph.cpp
 *
 *  Created on: 14:06 Friday 2022-9-9
 *      Author: Anonymity
 */

#include <algorithm>
#include <fstream>
#include <string>

#include "include/sorttrie/graph.hpp"
#include "include/sorttrie/iterator.hpp"
#include "include/sorttrie/join.hpp"
#include "include/sorttrie/node.hpp"
#include "include/utility/config.hpp"
#include "include/utility/graph.hpp"
#include "include/utility/utility.hpp"

namespace sorttrie {

// local type
typedef utility::graph::labelstr_index_t labelstr_index_t;

// local function
Node *CreateEdge(std::ifstream &in) {
    vid_t v_size, v, n_size;
    in.read(reinterpret_cast<char *>(&v_size), sizeof(vid_t));
    Node *root = new Node(v_size);
    while (v_size > 0) {
        in.read(reinterpret_cast<char *>(&v), sizeof(vid_t));
        in.read(reinterpret_cast<char *>(&n_size), sizeof(vid_t));
        vid_t *neighbor = new vid_t[n_size];
        in.read(reinterpret_cast<char *>(neighbor), sizeof(vid_t) * n_size);
        Node *leaf = new Node(n_size);
        for (vid_t i = 0; i < n_size; i++) {
            leaf->Append(neighbor[i]);
        }
        root->Append(v, leaf);
        v_size--;
        delete[] neighbor;
    }
    return root;
}

void ReadChunk(std::ifstream &in, Node **edge_1d, const lsize_t label_size,
        lsize_t *qlabel_1d, const lsize_t qlabel_size) {
    /* read folder/data.bin
     * qlabel_1d should be sorted in ascending order
     */
    eid_t chunk_size;
    if (qlabel_size) {
        // read query related data, based on query label id
        lsize_t j = 0;
        for (lsize_t label_id = 0; label_id < label_size; label_id++) {
            in.read(reinterpret_cast<char *>(&chunk_size), sizeof(eid_t));
            while ((j < qlabel_size) and (qlabel_1d[j] < label_id)) {
                j++;
            }
            if (j < qlabel_size) {
                // does not finish reading query related data
                if (qlabel_1d[j] == label_id) {
                    // query has this label id. read it
                    edge_1d[label_id] = CreateEdge(in);
                } else {
                    // current label does not appear in query. skip reading
                    in.seekg(chunk_size * sizeof(vid_t), std::ios_base::cur);
                }
            } else {
                // finish reading query related data
                break;
            }
        }
    } else {
        // read the entire graph for all labels
        for (lsize_t label_id = 0; label_id < label_size; label_id++) {
            in.read(reinterpret_cast<char *>(&chunk_size), sizeof(eid_t));
            edge_1d[label_id] = CreateEdge(in);
        }
    }
}

// public function
void VerifyBinaryGraph(utility::Config &config) {
    std::string bin_file = config.BinarySortTrie();
    if (utility::graph::HasBinaryData(bin_file, config.LabelFile())) {
        return;
    }
    PrintLCTX("create files for a binary SortTrie graph at:");
    PrintLCTX(bin_file);
    PrintLCTX(config.LabelFile());
    utility::graph::TextToBinary text2bin(config);
    utility::graph::edge_map_1d_t edge_map_1d;
    labelstr_index_t labelstr_index;
    vid_t max_vertex = 0;
    text2bin.ReadTextGraph(edge_map_1d, labelstr_index, max_vertex);
    /*
     * convert a graph in text (graph_file) to a binary dataset
     * create data_file and label_file if any is missing
     *
     * data graph file format
     * [0] number of labels
     * [1] length of the data for neighbor list for label id = 0, (e.g., 12)
     * [2] number of vertexes [0...number)
     * [3] vertex 0
     * [4] vertex 0 neighbor size (e.g., 5)
     * [5..9] vertex 0 neighbor in sorted order
     * [10] vertex 1
     * [11] vertex 1 neighbor size (e.g., 2)
     * [12..13] vertex 1 neighbor in sorted order
     * [14] length of the data for neighbor list for label id = 1
     * ...
     *
     */
    text2bin.WriteBinHeader(bin_file, edge_map_1d, labelstr_index, max_vertex);
    for (size_t i = 0; i < labelstr_index.size(); i++) {
        auto &e_map = edge_map_1d[i];
        vid_t *vertex_1d = new vid_t[e_map.size()];
        vid_t v_size = 0;
        eid_t chunk_size = 1; // collect the data size of the chunk
        for (auto it = e_map.begin(); it != e_map.end(); it++) {
            vertex_1d[v_size++] = it->first;
            // 2 for vertex, neighbor size
            chunk_size += (2 + it->second.size());
        }
        text2bin.out.write(reinterpret_cast<char *>(&chunk_size),
                sizeof(eid_t));
        text2bin.out.write(reinterpret_cast<char *>(&v_size), sizeof(vid_t));
        std::sort(vertex_1d, vertex_1d + v_size);
        for (vid_t j = 0; j < v_size; j++) {
            auto v = vertex_1d[j];
            text2bin.out.write(reinterpret_cast<char *>(&v), sizeof(vid_t));
            vid_t *neighbor_1d = new vid_t[e_map[v].size()];
            vid_t n_size = 0;
            for (auto n : e_map[v]) {
                neighbor_1d[n_size++] = n;
            }
            std::sort(neighbor_1d, neighbor_1d + n_size);
            text2bin.out.write(reinterpret_cast<char *>(&n_size),
                    sizeof(vid_t));
            text2bin.out.write(reinterpret_cast<char *>(neighbor_1d),
                    sizeof(vid_t) * n_size);
            delete[] neighbor_1d;
        }
        delete[] vertex_1d;
    }
}

// public method
void Graph::WriteText(const std::string &label_file,
        const std::string &out_file) const {
    // test purpose
    utility::graph::BinaryToText bin2text(label_file, out_file);
    // convert and save data into bin2text
    for (lsize_t i = 0; i < this->label_size_; i++) {
        for (Iterator root(this->edge_1d_[i]); root.InRange(); root.Next()) {
            auto src = root.Value();
            for (Iterator leaf(root.GetNode()); leaf.InRange(); leaf.Next()) {
                utility::graph::InsertEdge(src, leaf.Value(),
                        bin2text.edge_map);
                bin2text.edge_to_label_id[ToString2(src, leaf.Value())] = i;
            }
        }
    }
    // finally write
    bin2text.WriteTextGraph();
}

eid_t Graph::EdgeSize(const lsize_t edge_index) const {
    eid_t leaf_size = 0;
    for (auto root = Iterator(this->Edge(edge_index)); root.InRange();
            root.Next()) {
        for (auto leaf = Iterator(root.GetNode()); leaf.InRange();
                leaf.Next()) {
            leaf_size += leaf.Size();
        }
    }
    return leaf_size;
}

Graph::Graph(utility::Config &config)
        : optim::Graph(config.BinarySortTrie(), config.LabelFile()) {
    this->edge_1d_ = new Node*[this->label_size_];
    ReadChunk(this->in_, this->edge_1d_, this->label_size_, 0, 0);
    this->in_.close();
#ifndef NDEBUG
    // initialize global debug variable
    join::VERTEX_SIZE = this->vertex_size_;
#endif
}

}
