/*
 * query.hpp
 *
 * represent the query / pattern graph
 *
 *  Created on: 0:05 Sunday 2022-8-28
 *      Author: Anonymity
 */

#ifndef INCLUDE_CSR_QUERY_HPP_
#define INCLUDE_CSR_QUERY_HPP_

#include <string>

#include "include/common.hpp"
#include "include/utility/graph.hpp"

namespace csr {

class Query {
public:
    Query(bool, const std::string &, const std::string &);

    inline lsize_t GetLabelIndex(const cid_t a, const cid_t b) {
        return this->labelstr_index_[ToString2(a, b)];
    }

private:
    edge_map_t edge_map_;
    /*
     * label_map_: two vertices -> tuple (sl, dl, el, tl)
     * index the corresponding CSR from data
     */
    utility::graph::edge_to_labelarray_t label_map_;
    utility::graph::labelstr_index_t labelstr_index_;
};

} // namespace csr

#endif /* INCLUDE_CSR_QUERY_HPP_ */
