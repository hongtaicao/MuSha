/*
 * singledirected_csr.hpp
 *
 *  Created on: 13:39 PM 2023-05-23
 *      Author: Anonymity
 */

#ifndef INCLUDE_CSR_COMPILE_SINGLEDIRECTED_CSR_HPP_
#define INCLUDE_CSR_COMPILE_SINGLEDIRECTED_CSR_HPP_

namespace utility {

class Config;
class Logger;

} // namespace utility

namespace csr {

class Graph;

namespace compile {

namespace singledirected_csr {

typedef utility::Config Config;
typedef utility::Logger Logger;

bool ExecuteByQueryName(Config &, const Graph &, Logger &);

} // namespace automine_csr

} // namespace compile

} // namespace csr

#endif /* INCLUDE_CSR_COMPILE_SINGLEDIRECTED_CSR_HPP_ */
