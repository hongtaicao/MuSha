/*
 * execution.hpp
 *
 * the bridge between optimization (topdown) result and execution (sorttrie)
 *
 * hold variable for execution and execution order
 * can build both function name for execute compiled
 * and function argument for execute dynamic
 *
 * additional function compared to optim::Expression
 * 1. execute Join Expressions together if intermediate result is not shared
 * 2. find symmetry breaking rule that should be performed in execution
 * 3. input Operand are already sorted to standardize execution function name
 *
 * note
 * 1. everything is referenced by the index of output vertex
 * e.g., 0-th output vertex
 * unlike optimization which uses order (or permutation) of Query.v_1d
 * in the execution stage, order is carried from input unless transposed
 * therefore cannot use order (or permutation)
 * the benefit is that
 * input Operand can be re-orderd
 * symmetry breaking rule can be re-ordered
 *
 *  Created on: Friday 15:11 PM 2023-2-10
 *      Author: Anonymity
 */

#ifndef INCLUDE_ABSTRACT_EXECUTION_HPP_
#define INCLUDE_ABSTRACT_EXECUTION_HPP_

#include <string>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/optim/type.hpp"

namespace abstract {

// used in expression function name
extern const std::string AllMatchInput;     // non-edge all match
extern const std::string IndexSeparator;    // separate vertex index
extern const std::string MarkEdge;          // input edge Operand
extern const std::string MarkInput;         // input Operand
extern const std::string MarkNegation;      // negation in join
extern const std::string MarkSymBreak;      // symmetry breaking rule
extern const std::string MismatchInput;
extern const std::string NonedgeAdd;        // non-edge input name

class Expression;
class Operand;

class Execution {
public:
    // forward declare a nested class
    Execution();
    ~Execution();

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    inline void DebugPrint(bool end_of_line) const {
        this->PrintDetail(end_of_line);
    }
#endif

    inline bool IsInput(Operand *operand) const {
        // input does not have an Expression to compute its value
        return not this->op_to_expr.count(operand);
    }

    Expression *NewExpression(Operand *);
    Operand *NewOperand();

    void PrintDetail(bool) const;

    // the final output of the Execution
    Operand *output;
    /* each Operand has only one Expression to compute it
     * therefore can map an Operand to the Expression that computes itself
     */
    std::unordered_map<Operand *, Expression *> op_to_expr;
    /* owner
     * all Expression that should be executed
     * its creation order follows the optimization top-down order
     * therefore it preserves the actual execution order
     * from the end to the begin
     */
    std::vector<Expression *> expression_1d;
    // owner. contains all input Operand in Expression
    std::vector<Operand *> operand_1d;
};

}

#endif /* INCLUDE_ABSTRACT_EXECUTION_HPP_ */
