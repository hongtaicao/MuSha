/*
 * hypergeometric.hpp
 *
 * assume a Erdos-Renyi random graph model
 * assume vertex neighbors are random uniformly distributed
 * use hyper-geometric distribution
 * to estimate relation size and join selectivity
 *
 *  Created on: 10:48 AM Monday 2022-11-07
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_COSTMODEL_HYPERGEOMETRIC_HPP_
#define INCLUDE_OPTIM_COSTMODEL_HYPERGEOMETRIC_HPP_

#include "include/common.hpp"
#include "include/optim/costmodel.hpp"
#include "include/optim/graph.hpp"
#include "include/optim/type.hpp"

namespace optim {

class Query;

namespace costmodel {

class HyperGeometric: public CostModel {
public:
    HyperGeometric(Config &config, Graph &graph, Query *query,
            SymBreak &sb)
            : CostModel(config, graph, query, sb) {
    }

private:
    void InitializeSizeTable(Operand *, trie_size_1d_t &) override;
    inline double ExpectMatchSize(double a, double b) const {
        return a / this->graph_.VertexSize() * b;
    }
};

} // namespace costmodel

} // namespace optim

#endif /* INCLUDE_OPTIM_COSTMODEL_HYPERGEOMETRIC_HPP_ */
