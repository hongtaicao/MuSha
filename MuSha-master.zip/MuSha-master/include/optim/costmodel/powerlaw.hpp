/*
 * powerlaw.hpp
 *
 * implement 2016-Scalable Distributed Subgraph Enumeration
 * use power law random graph model to estimate relation size
 *
 *  Created on: 10:42 Monday 2022-11-07
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_COSTMODEL_POWERLAW_HPP_
#define INCLUDE_OPTIM_COSTMODEL_POWERLAW_HPP_

#include <unordered_map>

#include "include/common.hpp"
#include "include/optim/costmodel.hpp"
#include "include/optim/type.hpp"

namespace optim {

// forward declaration
class Graph;
class Query;

namespace costmodel {

class PowerLaw: public CostModel {
public:
    PowerLaw(Config &, Graph &, Query *, SymBreak &);
    ~PowerLaw() {
        delete[] this->gamma_1d_;
    }

private:
    void InitializeSizeTable(Operand *, trie_size_1d_t &) override;

    /*
     * see 2016-Scalable Distributed Subgraph Enumeration Technical Report
     * page 6 Power-Law Random (PR) Graph Model
     */
    double *gamma_1d_;
    std::unordered_map<eid_t, double> label_ratio_;
    double rho_;
};

} // namespace costmodel

} // namespace optim

#endif /* INCLUDE_OPTIM_COSTMODEL_POWERLAW_HPP_ */
