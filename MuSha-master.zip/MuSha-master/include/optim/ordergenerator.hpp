/*
 * ordergenerator.hpp
 *
 * order generator to avoid autormorphic order given by mapping_1d
 *
 *  Created on: 14:52 PM Monday 2022-11-14
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_ORDERGENERATOR_HPP_
#define INCLUDE_OPTIM_ORDERGENERATOR_HPP_

#include "include/optim/type.hpp"

namespace optim {

class OrderGenerator {
public:
    virtual ~OrderGenerator() {
    }

    virtual bool InRange() = 0;
    virtual void Next() = 0;

    vid_1d_t permutation;

protected:
    OrderGenerator() {
    }
};

} // namespace optim

#endif /* INCLUDE_OPTIM_ORDERGENERATOR_HPP_ */
