/*
 * topologytable.hpp
 *
 * keep track of all query and their isomorphism relationship
 *
 *  Created on: 17:35 PM Monday 2022-10-31
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_TOPOLOGYTABLE_HPP_
#define INCLUDE_OPTIM_TOPOLOGYTABLE_HPP_

#include <assert.h>
#include <unordered_map>
#include <vector>

#include "include/common.hpp"
#include "include/optim/type.hpp"

namespace optim {

class Query;

class TopologyTable {
public:
    TopologyTable() {
        DPrintLCTX("this=" << this << " TopologyTable()");
        // used in utility::graph, declaration in Optimizer
        this->topology_table_.push_back(nullptr); // reserved
        assert(this->topology_table_.size() == 1);
    }
    // used in Optimizer initialization
    TopologyTable(Config &);
    // copy construct
    TopologyTable(const TopologyTable &) = delete;
    // copy assignment
    TopologyTable &operator=(const TopologyTable &) = delete;

    ~TopologyTable();

    inline Query *operator[](const tid_t qid) {
        return this->topology_table_[qid];
    }
    inline Query *GetRootQuery() {
        // this is the Query created in the constructor
        return this->topology_table_[1];
    }
    inline Query *GetTopology(const tid_t qid) {
        return this->topology_table_[qid];
    }

    /* return true if the query is a new topology
     * use in decomposition
     */
    bool Index(Query *);
    inline size_t Size() const {
        // number of Query indexed so far. also the next available query id
        return this->topology_table_.size();
    }

private:
    // track topology. isomorphic Query is tracked only once
    std::vector<Query *> topology_table_;
    /* find isomorphic queries, the topology
     * each topology has a topology id
     * topology id: the first query with such topology
     */
    std::unordered_map<size_t, std::vector<Query *>> hash_to_topology_;
};

} // namespace optim

#endif /* INCLUDE_OPTIM_TOPOLOGYTABLE_HPP_ */
