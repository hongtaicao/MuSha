/*
 * type.hpp
 *
 * define common types used in optimization
 *
 *  Created on: 13:30 PM Friday 2022-10-28
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_TYPE_HPP_
#define INCLUDE_OPTIM_TYPE_HPP_

#include <vector>

#include "include/common.hpp"

namespace utility {

class Config;

} // namespace utility

namespace optim {

// forward declaration
class Expression;
class Operand;

typedef utility::Config Config;

typedef std::vector<Expression *> expression_1d_t;
typedef std::vector<Operand *> operand_1d_t;

typedef size_t tid_t;           // topology id, based on TopologyTable.size()

} // namespace optim

#endif /* INCLUDE_OPTIM_TYPE_HPP_ */
