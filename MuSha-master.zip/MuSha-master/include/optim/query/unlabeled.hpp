/*
 * unlabeled.hpp
 *
 *  Created on: 15:47 PM Saturday 2022-10-29
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_QUERY_UNLABELED_HPP_
#define INCLUDE_OPTIM_QUERY_UNLABELED_HPP_

#include "include/common.hpp"
#include "include/optim/query/base.hpp"
#include "include/optim/type.hpp"
#include "include/utility/graph.hpp"

namespace optim {

namespace query {

class Unlabeled: public Base {
public:
    Unlabeled(Config &);
    // used in sample induced subgraph
    Unlabeled(edge_map_t &, const vid_set_t &);

    inline bool IsomorphicTo(Query *a, const vid_t vi, const vid_t vj, Query *b,
            const vid_t xi, const vid_t xj) override {
        // check isomorphism between an edge pair
        auto count = a->HasEdge(vi, vj) + b->HasEdge(xi, xj);
        if (count == 1) {
            // out-going edge not match
            return false;
        }
        count = a->HasEdge(vj, vi) + b->HasEdge(xj, xi);
        if (count == 1) {
            // in-coming edge not match
            return false;
        }
        return true;
    }

    // give DEFAULT_LABEL to both vertex and edge
    inline vid_t Label(const vid_t) override {
        return utility::graph::DefaultLabel;
    }
    inline eid_t Label(const vid_t a, const vid_t b) override {
        return utility::graph::DefaultLabel;
    }
};

} // namespace query

} // namespace optim

#endif /* INCLUDE_OPTIM_QUERY_UNLABELED_HPP_ */
