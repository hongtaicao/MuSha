/*
 * decomposition.hpp
 *
 *  Created on: 16:50 PM Saturday 2022-10-29
 *      Author: Anonymity
 */

#include <unordered_map>

#include "include/common.hpp"
#include "include/optim/type.hpp"

namespace optim {

class Query;

namespace topdown {

class Decomposition {
public:
    Decomposition(Query *query)
            : topology(query) {
    }

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    void DebugPrint(bool) const;
#endif

    inline bool HasParentIndex(vid_t parent_index) const {
        // true if this decomposed Query has its parent Query vertex
        return this->p_to_sub_index.count(parent_index);
    }
    void MapParentIndex(const size_t, Query *);
    Query *topology;
    // parent Query->v_1d index to subquery->v_1d index
    std::unordered_map<vid_t, vid_t> p_to_sub_index;

    // sort Decomposition to match the topology_order_ (join order)
    class Comparator {
    public:
        Comparator(const vid_1d_t &topology_order)
                : topology_order_(topology_order) {
        }

        bool operator()(const Decomposition *, const Decomposition *) const;

    private:
        /* topology -> sub-topology
         * this is the order of topology
         */
        const vid_1d_t &topology_order_;
    };
};

} // namespace topdown

} // namespace optim
