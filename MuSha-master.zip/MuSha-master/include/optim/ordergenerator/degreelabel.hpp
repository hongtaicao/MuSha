/*
 * degreelabel.hpp
 *
 * generate vertex matching order using label_frequency/degree
 *
 * if the query vertex has high degree in the query
 * and it has low label frequency in the data graph
 * then this query vertex has less data graph candidate vertexes
 * and therefore it should match first
 *
 * if tie, topology structure degree is more important than label frequency
 *
 *  Created on: 11:42 AM Thurday 2023-4-20
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_ORDERGENERATOR_DEGREELABEL_HPP_
#define INCLUDE_OPTIM_ORDERGENERATOR_DEGREELABEL_HPP_

#include "include/optim/type.hpp"
#include "include/optim/ordergenerator.hpp"

namespace optim {

class Graph;
class Query;

namespace ordergenerator {

void VertexToPermutation(const Query &, vid_1d_t &);

class DegreeLabel: public OrderGenerator {
public:
    DegreeLabel(Config &, const Graph &, Query &);

    inline bool InRange() override {
        return this->in_range_;
    }
    void Next() override;

private:
    void AddToGroup(const vid_t, vid_1d_t &);
    void BuildGroup1d();
    void MinLabelDegree(vid_1d_t &);

    bool in_range_;

    Config &config_;
    Query &query_;

    std::vector<vid_1d_t> group1d_;
    vid_1d_t group1d_index_;
    vid_1d_t vertex2permute_;
    vid_1d_t permute2freq_;             // for select vertex
    vid_1d_t permute2orbit_;            // for symmetry breaking
    vid_set_t select_permute_;          // selected vertex permutation
    edge_map_t undirected_edge_;        // for vertex degree
};

} // namespace ordergenerator

} // namespace optim

#endif /* INCLUDE_OPTIM_ORDERGENERATOR_DEGREELABEL_HPP_ */
