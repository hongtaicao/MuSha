/*
 * nonautomorphism.hpp
 *
 * an order generator implementation that skip automorphic vertex orders
 *
 *  Created on: 2:07 AM Thursday 2023-4-20
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_ORDERGENERATOR_NONAUTOMORPHISM_HPP_
#define INCLUDE_OPTIM_ORDERGENERATOR_NONAUTOMORPHISM_HPP_

#include <string>
#include <unordered_set>

#include "include/optim/ordergenerator.hpp"
#include "include/optim/type.hpp"

namespace optim {

namespace ordergenerator {

class NonAutomorphism: public OrderGenerator {
public:
    NonAutomorphism(vid_2d_t &);

    inline bool InRange() override {
        return this->in_range_;
    }
    void Next() override;

private:
    bool IsNewOrder();

    bool in_range_;
    const vid_2d_t &mapping_1d_;
    std::unordered_set<std::string> order_set_;
};

} // namespace ordergenerator

} // namespace optim

#endif /* INCLUDE_OPTIM_ORDERGENERATOR_NONAUTOMORPHISM_HPP_ */
