/*
 * doublenode.hpp
 *
 * doubly linked tree node
 * search constraint by topology vertex
 *
 *  Created on: 23:44 PM Saturday 2022-12-03
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_SYMBREAK_DOUBLENODE_HPP_
#define INCLUDE_OPTIM_SYMBREAK_DOUBLENODE_HPP_

#include <cstdlib>          // size_t
#include <unordered_map>

#include "include/optim/type.hpp"

namespace optim {

namespace symbreak {

class SingleNode;

class DoubleNode {
    // top-down search tree of constraint
public:
    DoubleNode(const SingleNode *constraint_, const size_t depth_,
            const size_t node_id_, const DoubleNode *parent_)
            : constraint(constraint_), depth(depth_), node_id(node_id_), parent(
                    parent_) {
    }
    ~DoubleNode();

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
    inline void DebugPrintAll() const {
    }
    inline void DebugPrintChain(bool) const {
    }
#else
    void DebugPrint(bool) const;
    void DebugPrintAll() const;
    void DebugPrintChain(bool) const;
#endif

    const SingleNode *constraint;       // owner is SymBreak.constraint_set
    const size_t depth;                 // the depth of node
    const size_t node_id;               // a unique id
    const DoubleNode *parent;           // leaf to root search
    std::unordered_map<order_t, DoubleNode *> index_to_node; // root to leaf
};

} // namespace symbreak

} // namespace optim

#endif /* INCLUDE_OPTIM_SYMBREAK_DOUBLENODE_HPP_ */
