/*
 * symbreak.hpp
 *
 * manage constraints for symmetry breaking
 *
 *  Created on: 16:05 PM Monday 2022-11-14
 *      Author: Anonymity
 */

#ifndef INCLUDE_OPTIM_SYMBREAK_SYMBREAK_HPP_
#define INCLUDE_OPTIM_SYMBREAK_SYMBREAK_HPP_

#include <cstdlib>          // size_t
#include <unordered_set>
#include <vector>

#include "include/common.hpp"
#include "include/optim/type.hpp"

namespace optim {

namespace symbreak {

class SingleNode;

class SymBreak {
    // default is private
public:

    typedef std::unordered_set<SingleNode *> snode_set_t;
    typedef std::vector<SingleNode *> snode_1d_t;

    SymBreak() {
    }
    ~SymBreak();

    // copy construct
    SymBreak(const SymBreak &) = delete;
    // copy assignment
    SymBreak &operator=(const SymBreak &) = delete;

    void Initialize(Config &c, const vid_2d_t &);

    inline size_t Size() const {
        return this->query_constraint.size();
    }

    class Generator {
        // nested class can access private members
    public:
        Generator(SymBreak &symmetrybreak)
                : symmetrybreak_(symmetrybreak) {
            // used to generate constraint for Query
            this->index_ = 0;
        }

        inline bool InRange() const {
            DPrintLCTX("use symmetry breaking rule index=" << this->index_);
            return this->index_ < this->symmetrybreak_.query_constraint.size();
        }
        SingleNode *Item() const {
            /* return the constraint node
             * assume range check is performed
             * this should be called only once for the root Query
             */
            return this->symmetrybreak_.query_constraint[this->index_];
        }
        inline void Next() {
            this->index_++;
        }

    private:
        size_t index_;
        SymBreak &symmetrybreak_;
    };

private:
    // for resource management
    snode_set_t constraint_set;
    /* all possible constraint to break symmetry in the initial Query
     * each constraint is a linked list of conditions
     * each condition is a list of index of Query vertex
     * such that the first index corresponding vertex is bound to the smallest
     * among all other vertexes within the same list
     */
    snode_1d_t query_constraint;
};

namespace graphpi {

typedef typename SymBreak::snode_1d_t snode_1d_t;
typedef typename SymBreak::snode_set_t snode_set_t;

void Generate(const vid_2d_t &, SingleNode *, snode_1d_t &, snode_set_t &);
bool HasCycle(edge_map_t &, vid_set_t &, vid_set_t &);
void Initialize(const vid_2d_t &, vid_2d_t &);
bool SatisfyConstraint(const vid_1d_t &, SingleNode *);

} // namespace graphpi

namespace paper2007 {

typedef typename SymBreak::snode_1d_t snode_1d_t;
typedef typename SymBreak::snode_set_t snode_set_t;

void Generate(size_t, const size_t, const vid_2d_t &, SingleNode *,
        snode_1d_t &, snode_set_t &);

} // namespace paper2007

} // namespace symbreak

} // namespace optim

#endif /* INCLUDE_OPTIM_SYMBREAK_SYMBREAK_HPP_ */
