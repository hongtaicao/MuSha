/*
 * common.hpp
 *
 * define types, macros
 *
 *  Created on: 1:57 AM Monday 2022-8-29
 *      Author: Anonymity
 */

#ifndef INCLUDE_COMMON_HPP_
#define INCLUDE_COMMON_HPP_

#include <iostream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

// uint32_t = 4,294,967,295 = 2^32 - 1
typedef uint32_t vid_t;     // 4 bytes. vertex id type, vertex label type
typedef uint32_t eid_t;     // 4 bytes. edge id type, edge label type
typedef eid_t rid_t;        // number of edges. row index of CSR
typedef vid_t cid_t;        // number of vertices. column index of CSR
typedef eid_t lsize_t;      // number of (vlabel, vlabel, elabel, topology)
// unconnected=0, bi-directed=1, in-coming=2, out-going=3

typedef vid_t order_t;                              // Operand.order index
typedef std::unordered_map<vid_t, size_t> vid_map_t;
typedef std::unordered_set<vid_t> vid_set_t;
typedef std::unordered_map<vid_t, vid_set_t> vid_vset_map_t;
typedef vid_vset_map_t edge_map_t;
typedef std::unordered_set<order_t> order_set_t;    // constraint as a set
typedef std::vector<lsize_t> edge_index_1d_t;
typedef std::vector<vid_t> vid_1d_t;                // vertex id
typedef std::vector<vid_1d_t *> vid_2d_t;
typedef std::vector<order_t> order_1d_t;            // Operand.order
typedef std::vector<order_1d_t *> order_2d_t;       // constraint 1d
typedef std::vector<std::string> string_1d_t;

// see sorttrie/iterator.cpp
//#define SORTTRIE_LINEAR_SEARCH
#define SORTTRIE_MIX_SEARCH

#define Bool_String(x)          ((x) ? "true" : "false")
#define ToString2(a, b)         (std::to_string(a) + " " + std::to_string(b))
#define ToString4(a, b, c, d)   (ToString2(a, b) + " " + ToString2(c, d))
#define LabelarrayToString(x)   ToString4(x[0], x[1], x[2], x[3])

#define Print(x)                std::cout << x
#define PrintLine(x)            std::cout << x << std::endl

template<typename T1, typename T2>
void PrintArray(T1 &&array, T2 size) {
    for (T2 i = 0; i < size; i++) {
        std::cout << array[i] << " ";
    }
}

#ifdef NDEBUG

#define DPrintCollection(x)                                     (void (0))
#define DContext(x)                                             "" << x
#define DPrint(x)                                               (void (0))
#define DPrintArray(x, y)                                       (void (0))
#define DPrintCTX(x)                                            (void (0))
#define DPrintLine(x)                                           (void (0))
#define DPrintLCTX(x)                                           (void (0))

#else

#ifndef DPRINT_LIMIT
// compile flag DPRINT_LIMIT undefined, set a default value
#define DPRINT_LIMIT 30
#endif

#define DContext(x)             __FILE__ << " " << __func__ << "() " << x
#define DPrint(x)               std::cout << x

template<typename T1, typename T2>
void DPrintArray(T1 &&array, T2 size) {
    PrintArray(array, size);
}

template<typename T>
void DPrintCollection(T &&collection) {
    for (auto &item : collection) {
        std::cout << item << " ";
    }
}

#define DPrintCTX(x)    std::cout << DContext(x)
#define DPrintLCTX(x)   std::cout << DContext(x) << std::endl
#define DPrintLine(x)   std::cout << x << std::endl
#endif

#define PrintCTX(x)     std::cout << DContext(x)
#define PrintLCTX(x)    std::cout << DContext(x) << std::endl
#define SystemExit(x)   PrintLine(DContext("System Exits.")); exit(x)

#endif /* INCLUDE_COMMON_HPP_ */
