/*
 * adhoc.hpp
 *
 *  Created on: 0:59 AM Sunday 2022-9-11
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_COMPILE_ADHOC_HPP_
#define INCLUDE_SORTTRIE_COMPILE_ADHOC_HPP_

namespace utility {

class Config;
class Logger;

} // namespace utility

namespace sorttrie {

class Graph;

namespace compile {

namespace adhoc {

typedef utility::Config Config;
typedef utility::Logger Logger;

bool ExecuteByQueryName(Config &, const Graph &, Logger &);

} // namespace adhoc

} // namespace compile

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_COMPILE_ADHOC_HPP_ */
