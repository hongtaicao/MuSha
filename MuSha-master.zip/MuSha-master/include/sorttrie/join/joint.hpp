/*
 * joint.hpp
 *
 * a join over two Iterator(Node)
 *
 *  Created on: 16:50 PM Wednesday 2023-3-1
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINT_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINT_HPP_

#include "include/sorttrie/join.hpp"

namespace sorttrie {

namespace join {

class JoinT: public sorttrie::Join {
    // a specialized implementation for a two relation join
public:
    JoinT(Iterator **iterator)
            : iterator_a_(iterator[0]), iterator_b_(iterator[1]) {
        // find the first join value
        DPrintCTX("**iter=" << iterator << " iter_a=" << iterator[0]);
        DPrintLine(" iter_b=" << iterator[1]);
        this->iterator_a_->DebugPrint(true);
        this->iterator_b_->DebugPrint(true);
        if (this->InRange()) {
            if (this->iterator_a_->Value() < this->iterator_b_->Value()) {
                this->iterator_a_->Next();
            } else if (this->iterator_a_->Value()
                    > this->iterator_b_->Value()) {
                this->iterator_b_->Next();
            } else {
                return;
            }
            this->MatchValue();
        }
    }
    virtual ~JoinT() {
        delete this->iterator_a_;
        delete this->iterator_b_;
    }

    // return the index-th child Node of the join value
    inline Node *Child(vid_t index) const override {
        if (index) {
            return this->iterator_b_->GetNode();
        }
        return this->iterator_a_->GetNode();
    }

    virtual inline Node *Child0(vid_t) const override {
        DPrintLCTX("method called on a wrong Join");
        SystemExit(-1);
    }

    inline bool InRange() const override {
        return this->iterator_a_->InRange() and this->iterator_b_->InRange();
    }

    // should be at a join value when calling this function
    virtual inline void Next() override {
        // can Next() either one of the Iterator
        this->iterator_a_->Next();
        this->MatchValue();
    }
    /*
     *  value is always the join value
     *  therefore can return any one of them
     */
    inline value_t Value() const override {
        return this->iterator_a_->Value();
    }

private:
    void MatchValue();

    // owner of Iterator *
    Iterator *iterator_a_, *iterator_b_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINT_HPP_ */
