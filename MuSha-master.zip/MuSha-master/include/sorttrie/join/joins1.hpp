/*
 * joins1.hpp
 *
 * join 1 relation and multiple leaf levels of negation
 *
 *  Created on: 10:16 AM Thursday 2023-3-2
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINS1_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINS1_HPP_

#include "include/sorttrie/join/joins.hpp"

namespace sorttrie {

namespace join {

class JoinS1: public join::JoinS {
public:
    JoinS1(Iterator **, Iterator **, vid_t);
    virtual ~JoinS1();

    // should be at a join value when calling this function
    inline void Next() override {
        join::JoinS::Next();
        this->Negate();
    }

private:
    void Negate();

    // owner of Iterator *, but not Iterator **
    Iterator **iterator1_;
    iterator_heap_t pool1_;
    size_type size1_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINS1_HPP_ */
