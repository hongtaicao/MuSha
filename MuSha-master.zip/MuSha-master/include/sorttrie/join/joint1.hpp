/*
 * joint1.hpp
 *
 * join 2 relations and multiple leaf levels of negation
 *
 *  Created on: 22:48 PM Thursday 2023-3-2
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINT1_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINT1_HPP_

#include "include/sorttrie/join/joint.hpp"

namespace sorttrie {

namespace join {

class JoinT1: public join::JoinT {
public:
    JoinT1(Iterator **, Iterator **, vid_t);
    virtual ~JoinT1();

    // should be at a join value when calling this function
    inline void Next() override {
        join::JoinT::Next();
        this->Negate();
    }

private:
    void Negate();

    // owner of Iterator *, but not Iterator **
    Iterator **iterator1_;
    iterator_heap_t pool1_;
    size_type size1_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINT1_HPP_ */
