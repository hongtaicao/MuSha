/*
 * join1.hpp
 *
 * join with leaf (1) level of negation
 *
 *  Created on: 1:48 AM Wednesday 2022-9-14
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOIN1_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOIN1_HPP_

#include "include/sorttrie/join/join.hpp"

namespace sorttrie {

namespace join {

class Join1: public join::Join {
public:
    Join1(Iterator **, vid_t, Iterator **, vid_t);
    ~Join1();

    // should be at a join value when calling this function
    inline void Next() override {
        join::Join::Next();
        this->Negate();
    }

private:
    void Negate();

    // owner of Iterator *, but not Iterator **
    Iterator **iterator1_;
    iterator_heap_t pool1_;
    size_type size1_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOIN1_HPP_ */
