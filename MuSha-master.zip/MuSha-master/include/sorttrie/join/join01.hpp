/*
 * join01.hpp
 *
 * join with both levels (root=0), (leaf=1) of negation
 *
 *  Created on: 1:48 AM Wednesday 2022-9-14
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOIN01_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOIN01_HPP_

#include "include/sorttrie/join/join1.hpp"

namespace sorttrie {

namespace join {

class Join01: public join::Join1 {
public:
    Join01(Iterator **iterator, vid_t size, Iterator **iterator0, vid_t size0,
            Iterator **iterator1, vid_t size1)
            : Join1(iterator, size, iterator1, size1) {
        /* iter0 contains self-loops and therefore they always join
         * they are not considered when join other iterators
         * need to adjust the pointer when requesting its leaf level
         */
        DPrintLCTX("**iterator0=" << iterator0 << " size0=" << size0);
        DPrintIterator(iterator0, size0);
        this->iterator0_ = iterator0;
        this->size0_ = size0;
    }
    ~Join01();

    // return the index-th child Node of the join value
    inline Node *Child0(vid_t index) const override {
        // need to adjust to the child level of the join value
        return this->iterator0_[index]->Equal(this->Value())->GetNode();
    }

private:
    // owner of Iterator *, but not Iterator **
    Iterator **iterator0_;
    size_type size0_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOIN01_HPP_ */
