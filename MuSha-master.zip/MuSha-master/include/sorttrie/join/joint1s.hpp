/*
 * joint1s.hpp
 *
 * join 2 relations and 1 leaf level of negation
 *
 *  Created on: 2:08 AM Friday 2023-3-3
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOINT1S_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOINT1S_HPP_

#include "include/sorttrie/join/joint.hpp"

namespace sorttrie {

namespace join {

class JoinT1S: public join::JoinT {
public:
    JoinT1S(Iterator **iterator, Iterator **iterator1)
            : JoinT(iterator), iterator1_(iterator1[0]) {
        // negation is not initialized. does not check negation
        DPrintLCTX("**iterator1=" << iterator1);
        this->iterator1_->DebugPrint(true);
        this->Negate();
    }
    virtual ~JoinT1S() {
        delete this->iterator1_;
    }

    // should be at a join value when calling this function
    inline void Next() override {
        join::JoinT::Next();
        this->Negate();
    }

private:
    void Negate();

    // owner of Iterator *
    Iterator *iterator1_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOINT1S_HPP_ */
