/*
 * join0.hpp
 *
 * join with root (0) level of negation
 *
 *  Created on: 1:46 AM Wednesday 2022-9-14
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_JOIN0_HPP_
#define INCLUDE_SORTTRIE_JOIN_JOIN0_HPP_

#include "include/sorttrie/join/join.hpp"

namespace sorttrie {

namespace join {

class Join0: public join::Join {
public:
    Join0(Iterator **iter, vid_t size, Iterator **iter0, vid_t size0)
            : Join(iter, size), iterator0_(iter0), size0_(size0) {
        DPrintLCTX("**iterator0=" << iter0 << " size0=" << size0);
        DPrintIterator(iter0, size0);
        AssertJoin0(iter0, size0);
    }
    ~Join0();

    // return the index-th child Node of the join value
    inline Node *Child0(vid_t index) const override {
        return this->iterator0_[index]->Equal(this->Value())->GetNode();
    }

private:
    // owner of Iterator *, but not Iterator **
    Iterator **iterator0_; // store NegationRoot
    size_type size0_;
};

} // namespace join

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_JOIN0_HPP_ */
