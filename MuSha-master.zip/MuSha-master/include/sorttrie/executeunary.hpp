/*
 * executeunary.hpp
 *
 * execute an operator without join, a single input operand
 *
 *  Created on: 22:32 PM Friday 2023-3-10
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_EXECUTEUNARY_HPP_
#define INCLUDE_SORTTRIE_EXECUTEUNARY_HPP_

#include <cstdlib>          // size_t
#include <vector>

#include "include/common.hpp"

namespace abstract {

class Expression;

} // namespace abstract

namespace sorttrie {

class Iterator;
class Node;

typedef typename abstract::Expression Expression;
typedef std::vector<Iterator *> iterator_1d_t;
typedef std::vector<Node *> node_1d_t;
typedef std::vector<order_1d_t> vec2_t;

class ExecuteUnary {
public:
    ExecuteUnary(const Expression *, Node *, const vid_t);
    ~ExecuteUnary();

    Node *Result();

private:
    void Initialize(size_t);
    Iterator *InitializeIndex(size_t) const;

    template<unsigned int N>
    Node *Transpose();

    const Expression *expression_;
    const Node *in_;
    vec2_t symbreak_low_;
    vec2_t symbreak_up_;

    // state variable used in computation
    const size_t depth_;
    const vid_t vertex_size_;
    iterator_1d_t iter_1d_;
    node_1d_t node_1d_;             // this 0-th Node * is release outside
};

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_EXECUTEUNARY_HPP_ */
