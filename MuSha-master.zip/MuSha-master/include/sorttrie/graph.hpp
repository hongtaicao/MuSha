/*
 * graph.hpp
 *
 * the data graph built using sort trie
 *
 *  Created on: 8:43 AM 2022-9-9
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_GRAPH_HPP_
#define INCLUDE_SORTTRIE_GRAPH_HPP_

#include <string>

#include "include/common.hpp"
#include "include/optim/graph.hpp"
#include "include/sorttrie/node.hpp"

namespace utility {

class Config;

} // namespace utility

namespace sorttrie {

void VerifyBinaryGraph(utility::Config &);

class Graph: public optim::Graph {
public:
    Graph(utility::Config &);

    inline Node *Edge(lsize_t edge_index) const {
        return this->edge_1d_[edge_index];
    }

    eid_t EdgeSize(const lsize_t) const override;

    vid_t OutDegree(const lsize_t edge_index, const vid_t ith) const override {
        return this->Root(edge_index, ith)->Size();
    }

    vid_t OutVertex(const lsize_t edge_index, const vid_t ith,
            const vid_t jth) const override {
        return this->Root(edge_index, ith)->Child(jth)->Value();
    }

    inline vid_t RootSize(const lsize_t edge_index) const override {
        return this->Edge(edge_index)->Size();
    }

    vid_t RootVertex(const lsize_t edge_index, const vid_t ith) const override {
        return this->Root(edge_index, ith)->Value();
    }

    void WriteText(const std::string &, const std::string &) const override;

private:
    inline Node *Root(const lsize_t edge_index, const vid_t ith) const {
        return this->Edge(edge_index)->Data()[ith];
    }

    Node **edge_1d_;
};

} // namespace

#endif /* INCLUDE_SORTTRIE_GRAPH_HPP_ */
