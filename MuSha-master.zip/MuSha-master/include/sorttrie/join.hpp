/*
 * join.hpp
 *
 * virtual base join class
 * sorttrie::join <- join::Join  <- join::Join0
 *                               <- join::Join1   <- join::Join01
 *                               <- join::Join1S  <- join::Join01S
 *                               <- join::Join1T  <- join::Join01T
 * sorttrie::join <- join::JoinS <- join::JoinS0
 *                               <- join::JoinS1  <- join::JoinS01
 *                               <- join::JoinS1S <- join::JoinS01S
 *                               <- join::JoinS1T <- join::JoinS01T
 * sorttrie::join <- join::JoinT <- join::JoinT0
 *                               <- join::JoinT1  <- join::JoinT01
 *                               <- join::JoinT1S <- join::JoinT01S
 *                               <- join::JoinT1T <- join::JoinT01T
 *
 *
 *  Created on: 10:28 AM Thursday 2023-3-2
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_JOIN_HPP_
#define INCLUDE_SORTTRIE_JOIN_HPP_

#include "include/common.hpp"                               // vid_t
#include "include/sorttrie/iterator.hpp"                    // heap_t
#include "include/sorttrie/node.hpp"                        // valut_t

namespace sorttrie {

typedef typename Iterator::iterator_min_heap_t iterator_heap_t;

#ifdef NDEBUG

#define AssertJoin0(x, y)                                       (void (0))

#else

namespace join {

// declare global debug variable
extern vid_t VERTEX_SIZE;

} // namespace join

void AssertJoin0(Iterator **, vid_t);

#endif

class Join {
public:
    virtual ~Join() {
    }

    /* return the index-th child Node of the join value
     * warning: inline function 'virtual ..' used but never defined
     * https://stackoverflow.com/a/24635897
     * If you are going to define the function in a .cpp file, you must
     * remove the inline specifier from the .h file.
     */
    virtual Node *Child(vid_t) const = 0;

    virtual Node *Child0(vid_t) const = 0;

    virtual bool InRange() const = 0;

    // should be at a join value when calling this function
    virtual void Next() = 0;
    virtual value_t Value() const = 0;
};

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_JOIN_HPP_ */
