/*
 * node.hpp
 *
 * sort trie node
 *
 *  Created on: 2:36 AM Wednesday 2022-9-7
 *      Author: Anonymity
 */

#ifndef INCLUDE_SORTTRIE_NODE_HPP_
#define INCLUDE_SORTTRIE_NODE_HPP_

#include <algorithm>
#include <cstdlib>          // size_t
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

#include "include/common.hpp"

namespace sorttrie {

class Node;

// https://www.learncpp.com/cpp-tutorial/78-function-pointers/
using expression_t = Node *(*)(std::vector<Node *> &);

typedef std::unordered_map<std::string, expression_t> expression_map_t;
typedef std::unordered_set<std::string> qname_set_t;

// element is 1 dimensional array
typedef std::vector<vid_t *> table_t;
typedef vid_t value_t;

class Node {
public:
    Node(const vid_t max_size)
            : data_(new Node*[max_size]), size_(0), value_(0) {
        // create internal node
    }
    Node(const std::vector<Node *> &, vid_t); // non-edge
    Node(const Node &) = delete; // copy constructor
    Node &operator=(const Node &) = delete; // copy assignment

    ~Node() {
        // should delete content of data_ first
        delete[] this->data_;
    }

    inline void Append(value_t value) {
        this->data_[this->size_] = new Node(value, 0, nullptr);
        this->size_++;
    }
    inline void Append(value_t value, Node &child) {
        /*
         * called inside sorttrie/expression, shrink memory allocation
         * move child.children_
         * reset child
         */
        if (child.HasChild()) {
            child.value_ = value;
            this->data_[this->size_] = child.ReSize();
            this->size_++;
        }
    }
    inline void Append(value_t value, Node *&child) {
        // called in sorttrie::Graph::CreateEdge, no shrink memory allocation
        if (child->HasChild()) {
            // directly own child
            child->value_ = value;
            this->data_[this->size_] = child;
            this->size_++;
        } else {
            // delete it since this is the owner
            delete child;
        }
        child = nullptr;
    }
    inline Node *Child(vid_t i) const {
        return this->data_[i];
    }

    // count the number of leaf nodes
    uint64_t CountLeaf();

    inline Node **Data() const {
        return this->data_;
    }

#ifdef NDEBUG
    inline void DebugPrint(bool) const {
    }
#else
    void DebugPrint(bool) const;
#endif

    size_t Depth() const;

    inline bool HasChild() const {
        return this->size_ > 0;
    }
    inline Node *ReSize() {
        // create a same node as self, with max size adjusted to save space
        Node *ret = new Node(this->value_, this->size_, new Node*[this->size_]);
        // move this.children_ -> ret->children_
        std::copy(this->data_, this->data_ + this->size_, ret->data_);
        // since this.children_ is moved to ret, reset this.size_
        this->size_ = 0;
        return ret;
    }

    vid_t SaveAsTable(const std::string &);

    inline vid_t Size() const {
        return this->size_;
    }

    // return table width. output table to the parameter
    vid_t ToTable(table_t &) const;

    inline value_t Value() const {
        return this->value_;
    }

private:
    Node(value_t value, vid_t size, Node **data)
            : data_(data), size_(size), value_(value) {
        // full constructor
    }

    Node **data_;
    vid_t size_;
    value_t value_;
};

typedef Node** pointer_t;
typedef std::vector<Node *> node_1d_t;

void InitializeNode1d(int, node_1d_t &, const vid_t);

} // namespace sorttrie

#endif /* INCLUDE_SORTTRIE_NODE_HPP_ */
